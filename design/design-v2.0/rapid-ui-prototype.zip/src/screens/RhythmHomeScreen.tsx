import React, { useState } from 'react';
import {
  CURRENT_USER,
  JUMP_BACK_IN_ITEMS,
  HEAVY_ROTATION_PACKS,
  SAMPLE_PHRASES,
  CIRCADIAN_WAVES,
} from '../data/mockData';
import { CadencePack, Phrase } from '../types';
import { playPorcelainTap, triggerHaptic } from '../utils/audioEngine';
import { PlayHistoryModal } from '../components/PlayHistoryModal';

interface RhythmHomeScreenProps {
  onOpenPack: (packId: string) => void;
  onStartWave: (waveId: string) => void;
  onPlayPhrase: (phrase: Phrase) => void;
  pack: CadencePack;
  isPlaying?: boolean;
  currentPhrase?: Phrase;
  onTogglePlay?: () => void;
}

export const RhythmHomeScreen: React.FC<RhythmHomeScreenProps> = ({
  onOpenPack,
  onStartWave,
  onPlayPhrase,
  pack,
  isPlaying = false,
  currentPhrase,
  onTogglePlay,
}) => {
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  return (
    <div className="flex flex-col w-full px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto space-y-7 pt-2 pb-36">
      {/* 1. GREETING & CIRCADIAN SCHEDULE HEADER */}
      <section className="flex flex-col space-y-3 pt-2">
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 mb-1">
              <span className="inline-block w-2 h-2 rounded-full bg-[#9f3c16] animate-pulse" />
              <span className="text-[11px] font-bold text-[#9f3c16] uppercase tracking-wider">
                Circadian Cycle • Golden Hour
              </span>
            </div>
            <h1 className="font-serif text-2xl md:text-3xl text-[#1c1c19] italic font-medium leading-tight">
              {CURRENT_USER.greeting}
            </h1>
            <p className="text-sm text-[#635d59] mt-0.5">
              Your daily rhythm · <span className="text-[#1c1c19] font-semibold">14 phrases due</span> before evening tapas
            </p>
          </div>
        </div>

        {/* Streak & Retention Stats Pill Bar (Responsive Grid with Clean Dividers) */}
        <div className="grid grid-cols-3 divide-x divide-[#dec0b7]/40 py-2.5 px-1.5 sm:p-3 bg-[#f6f3ee] border border-[#dec0b7]/40 rounded-2xl shadow-2xs">
          {/* Stat 1: Cadence Run */}
          <div className="flex flex-col sm:flex-row items-center justify-center sm:justify-start text-center sm:text-left gap-1.5 sm:gap-2.5 px-1 sm:px-3 min-w-0">
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-[#ffdbcf] flex items-center justify-center text-[#9f3c16] shrink-0">
              <span className="material-symbols-outlined text-[16px] sm:text-[18px] material-symbols-fill">
                local_fire_department
              </span>
            </div>
            <div className="min-w-0 flex flex-col">
              <p className="text-[9px] sm:text-[10px] uppercase tracking-wider text-[#635d59] font-bold truncate">
                Cadence Run
              </p>
              <p className="text-[11px] sm:text-xs text-[#1c1c19] font-bold truncate">
                {CURRENT_USER.repsSpaced}
              </p>
            </div>
          </div>

          {/* Stat 2: Acoustic Recall */}
          <div className="flex flex-col sm:flex-row items-center justify-center sm:justify-start text-center sm:text-left gap-1.5 sm:gap-2.5 px-1 sm:px-3 min-w-0">
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-[#d6e9c1] flex items-center justify-center text-[#111f07] shrink-0">
              <span className="material-symbols-outlined text-[16px] sm:text-[18px]">verified</span>
            </div>
            <div className="min-w-0 flex flex-col">
              <p className="text-[9px] sm:text-[10px] uppercase tracking-wider text-[#635d59] font-bold truncate">
                Acoustic Recall
              </p>
              <p className="text-[11px] sm:text-xs text-[#1c1c19] font-bold truncate">
                {CURRENT_USER.retentionPercent}
              </p>
            </div>
          </div>

          {/* Stat 3: Next Due */}
          <div className="flex flex-col sm:flex-row items-center justify-center sm:justify-start text-center sm:text-left gap-1.5 sm:gap-2.5 px-1 sm:px-3 min-w-0">
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-[#eae1db] flex items-center justify-center text-[#635d59] shrink-0">
              <span className="material-symbols-outlined text-[16px] sm:text-[18px]">schedule</span>
            </div>
            <div className="min-w-0 flex flex-col">
              <p className="text-[9px] sm:text-[10px] uppercase tracking-wider text-[#635d59] font-bold truncate">
                Next Due
              </p>
              <p className="text-[11px] sm:text-xs text-[#9f3c16] font-bold truncate">
                {CURRENT_USER.nextDue}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 2. CIRCADIAN RHYTHM WAVES (TODAY'S SCHEDULE - HORIZONTAL SCROLL) */}
      <section className="flex flex-col space-y-2.5">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-lg text-[#9f3c16]">
                waves
              </span>
              <h2 className="font-serif text-lg md:text-xl text-[#1c1c19] font-semibold">
                Circadian Waves
              </h2>
            </div>
            <p className="text-xs text-[#635d59] mt-0.5">
              Spaced acoustic immersion tuned to your daily circadian energy peaks
            </p>
          </div>

          <div className="flex items-center gap-1 bg-[#f0ede9] text-[#635d59] px-2.5 py-1 rounded-full text-[11px] font-semibold shrink-0">
            <span className="w-1.5 h-1.5 rounded-full bg-[#9f3c16] animate-pulse" />
            <span>3 Waves</span>
          </div>
        </div>

        {/* Horizontal Scrolling Wave Cards */}
        <div className="flex gap-3.5 overflow-x-auto pb-2 pt-1 -mx-4 px-4 sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8 snap-x snap-mandatory scrollbar-none scroll-smooth">
          {CIRCADIAN_WAVES.map((wave) => {
            const isDueNow = wave.state === 'due';
            const isLocked = wave.state === 'locked';

            return (
              <div
                key={wave.id}
                className={`snap-start shrink-0 w-[84vw] min-w-[285px] max-w-[340px] sm:w-[340px] md:w-[360px] flex flex-col justify-between rounded-2xl p-3.5 sm:p-4 transition-all duration-200 border select-none ${
                  isDueNow
                    ? 'bg-gradient-to-br from-[#ffffff] via-[#fffaf7] to-[#fbf5f0] border-[#dec0b7] shadow-[0_4px_16px_rgba(159,60,22,0.06)] ring-1 ring-[#9f3c16]/10'
                    : 'bg-[#ffffff]/90 border-[#ebe7e0] shadow-2xs opacity-95'
                }`}
              >
                {/* Wave Header Row */}
                <div>
                  <div className="flex items-start justify-between gap-2.5 mb-1.5">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider shrink-0 ${
                        isDueNow
                          ? 'bg-[#ffdbcf] text-[#822701]'
                          : 'bg-[#f0ede9] text-[#635d59]'
                      }`}
                    >
                      {wave.waveNumber}
                    </span>

                    {/* Status Badge */}
                    {isDueNow ? (
                      <span className="flex items-center gap-1 text-[11px] font-bold text-[#9f3c16] bg-[#ffdbcf]/60 px-2 py-0.5 rounded-full shrink-0">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#9f3c16] animate-ping" />
                        <span>Due Now</span>
                      </span>
                    ) : isLocked ? (
                      <span className="flex items-center gap-1 text-[11px] font-medium text-[#8a726a] bg-[#f0ede9] px-2 py-0.5 rounded-full shrink-0">
                        <span className="material-symbols-outlined text-[13px]">lock_clock</span>
                        <span>{wave.unlocksIn}</span>
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-[11px] font-medium text-[#635d59] bg-[#f0ede9] px-2 py-0.5 rounded-full shrink-0">
                        <span className="material-symbols-outlined text-[13px]">bedtime</span>
                        <span>Consolidation</span>
                      </span>
                    )}
                  </div>

                  <h3 className="font-serif text-base font-bold text-[#1c1c19] truncate">
                    {wave.title}
                  </h3>

                  <p className="text-xs text-[#635d59] leading-relaxed mt-1 line-clamp-2">
                    {wave.description}
                  </p>
                </div>

                {/* Waveform Visualization & Quick Controls */}
                <div className="pt-2.5 sm:pt-3 mt-2.5 sm:mt-3 border-t border-[#f0ede9] flex items-center justify-between gap-1.5 sm:gap-2.5">
                  <div className="flex items-center gap-1.5 sm:gap-2 min-w-0 flex-1">
                    {/* Visual Waveform Equalizer */}
                    <div className="flex items-end gap-0.5 sm:gap-1 h-7 px-1.5 sm:px-2 py-0.5 rounded-xl bg-[#f6f3ee] border border-[#dec0b7]/30 shrink-0">
                      {wave.wavePattern.map((val, barIdx) => {
                        const heightPercent = Math.max(18, (val / 10) * 100);
                        return (
                          <span
                            key={barIdx}
                            className={`w-[2.5px] sm:w-1 rounded-full transition-all duration-300 ${
                              isDueNow
                                ? isPlaying
                                  ? 'bg-[#bf542c] animate-pulse'
                                  : 'bg-[#9f3c16]'
                                : 'bg-[#cfc9c2]'
                            }`}
                            style={{
                              height: `${heightPercent}%`,
                              animationDelay: `${barIdx * 0.06}s`,
                            }}
                          />
                        );
                      })}
                    </div>

                    {/* Cadence Metrics */}
                    <div className="flex flex-col text-[10px] sm:text-[11px] text-[#635d59] font-medium min-w-0 flex-1 leading-tight">
                      <span className="font-bold text-[#1c1c19] text-[11px] sm:text-xs whitespace-nowrap">
                        {wave.bpm} BPM
                      </span>
                      <span className="truncate text-[9px] sm:text-[10px] text-[#635d59]">
                        {wave.phraseCount} phrases • {wave.durationMins}m
                      </span>
                    </div>
                  </div>

                  {/* Action Button or Due Status */}
                  <div className="shrink-0 flex items-center">
                    {isDueNow ? (
                      <button
                        onClick={() => {
                          playPorcelainTap(1500);
                          triggerHaptic('medium');
                          onStartWave(wave.id);
                        }}
                        className="inline-flex items-center justify-center gap-1 px-3 sm:px-3.5 py-1.5 rounded-full bg-[#9f3c16] hover:bg-[#832f0e] text-white text-[11px] sm:text-xs font-bold shadow-xs active:scale-95 transition-all whitespace-nowrap cursor-pointer"
                        type="button"
                        aria-label={`Ride ${wave.title}`}
                      >
                        <span className="material-symbols-outlined text-[15px] sm:text-[16px] material-symbols-fill">
                          play_arrow
                        </span>
                        <span>Ride Wave</span>
                      </button>
                    ) : (
                      <span className="text-[10px] sm:text-[11px] text-[#8a726a] font-medium whitespace-nowrap bg-[#f6f3ee] px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full border border-[#ebe7e0]/60">
                        {wave.dueStatus}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. JUMP BACK IN (2-COLUMN COMPACT GRID) */}
      <section className="flex flex-col space-y-2.5">
        <div className="flex items-center justify-between">
          <h2 className="font-serif text-lg md:text-xl text-[#1c1c19] font-semibold">
            Jump Back In
          </h2>
          <button
            onClick={() => {
              playPorcelainTap(1300);
              setIsHistoryOpen(true);
            }}
            className="flex items-center gap-1 bg-[#f6f3ee] hover:bg-[#ffdbcf] text-[#9f3c16] border border-[#dec0b7]/50 hover:border-[#bf542c]/40 px-2.5 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider active:scale-95 transition-all shadow-2xs group cursor-pointer"
            type="button"
            aria-label="Open played sets history"
          >
            <span className="material-symbols-outlined text-[14px] transition-transform group-hover:rotate-[-20deg]">
              history
            </span>
            <span>History</span>
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {JUMP_BACK_IN_ITEMS.map((item) => (
            <button
              key={item.id}
              onClick={() => onOpenPack(item.packId)}
              className="flex items-center bg-[#ffffff] hover:bg-[#faf7f2] border border-[#dec0b7]/50 hover:border-[#bf542c]/40 rounded-2xl shadow-[0_2px_8px_rgba(28,28,25,0.03)] hover:shadow-[0_4px_14px_rgba(159,60,22,0.08)] overflow-hidden text-left p-1.5 active:scale-[0.98] transition-all duration-200 group cursor-pointer"
              type="button"
            >
              <div className="w-13 h-13 shrink-0 rounded-xl bg-[#ebe8e3] relative overflow-hidden shadow-2xs">
                <img
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  alt={item.title}
                  src={item.img}
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1c1c19]/30 to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />
                <div className="absolute bottom-1 right-1 w-4 h-4 rounded-full bg-[#ffffff]/90 flex items-center justify-center text-[#9f3c16] opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="material-symbols-outlined text-[11px] material-symbols-fill">play_arrow</span>
                </div>
              </div>
              <div className="flex flex-col min-w-0 px-2.5 py-1 flex-1">
                <h4 className="text-[13px] font-semibold text-[#1c1c19] truncate group-hover:text-[#9f3c16] transition-colors leading-tight">
                  {item.title}
                </h4>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-[11px] text-[#635d59] font-medium truncate">
                    {item.sub}
                  </span>
                </div>
              </div>
              <span className="material-symbols-outlined text-[16px] text-[#dec0b7] group-hover:text-[#9f3c16] group-hover:translate-x-0.5 transition-all pr-1 shrink-0">
                chevron_right
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* 4. HEAVY ROTATION EARWORM PACKS (ALBUM SHELF) */}
      <section className="flex flex-col space-y-2.5">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-serif text-lg md:text-xl text-[#1c1c19] font-semibold">
              Heavy Rotation Earworms
            </h2>
            <p className="text-xs text-[#635d59]">
              Rhythmic sentence structures engineered to stick
            </p>
          </div>
          <button
            onClick={() => onOpenPack('pack-cafe-mananas')}
            aria-label="View all packs"
            className="w-8 h-8 rounded-full bg-[#f0ede9] hover:bg-[#e5e2dd] flex items-center justify-center text-[#635d59] active:scale-90 transition-transform"
            type="button"
          >
            <span className="material-symbols-outlined text-lg">arrow_forward</span>
          </button>
        </div>

        <div className="flex gap-3.5 overflow-x-auto pb-2 -mx-4 px-4 sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8 scrollbar-none snap-x snap-mandatory">
          {HEAVY_ROTATION_PACKS.map((packItem) => {
            const targetPhrase =
              SAMPLE_PHRASES.find((p) => p.id === `phrase-${packItem.id.replace('rot-', '')}`) ||
              pack.phrases[0] ||
              SAMPLE_PHRASES[0];
            const isThisTrackActive = currentPhrase?.id === targetPhrase.id;
            const isThisPlaying = Boolean(isPlaying && isThisTrackActive);

            return (
              <div
                key={packItem.id}
                onClick={() => onOpenPack('pack-cafe-mananas')}
                className={`snap-start shrink-0 w-44 flex flex-col space-y-1.5 group cursor-pointer transition-transform ${
                  isThisPlaying ? 'scale-[1.01]' : ''
                }`}
              >
                <div
                  className={`relative w-44 h-44 rounded-2xl bg-[#f0ede9] overflow-hidden shadow-md border transition-all ${
                    isThisPlaying
                      ? 'border-[#bf542c] ring-2 ring-[#bf542c]/25 shadow-lg'
                      : 'border-[#dec0b7]/40'
                  }`}
                >
                  <img
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    alt={packItem.title}
                    src={packItem.img}
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-2 left-2 bg-[#ffffff]/90 backdrop-blur-md px-2 py-0.5 rounded-full text-[#1c1c19] text-[10px] font-semibold shadow-2xs">
                    {packItem.tag}
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      playPorcelainTap(1500);
                      triggerHaptic('medium');
                      if (isThisPlaying) {
                        onTogglePlay?.();
                      } else {
                        onPlayPhrase(targetPhrase);
                      }
                    }}
                    aria-label={isThisPlaying ? `Pause ${packItem.title}` : `Play ${packItem.title}`}
                    className={`play-disc absolute bottom-2 right-2 w-10 h-10 rounded-full text-white flex items-center justify-center shadow-lg active:scale-95 transition-all duration-300 cursor-pointer ${
                      isThisPlaying
                        ? 'bg-[#bf542c] ring-4 ring-[#ffdbcf] ring-offset-2 ring-offset-white scale-105 shadow-[#9f3c16]/35'
                        : 'bg-[#9f3c16] group-hover:scale-110'
                    }`}
                    type="button"
                  >
                    {isThisPlaying && (
                      <span className="absolute inset-0 rounded-full bg-[#bf542c] animate-ping opacity-30 pointer-events-none" />
                    )}
                    <span className="material-symbols-outlined text-xl material-symbols-fill relative z-10">
                      {isThisPlaying ? 'pause' : 'play_arrow'}
                    </span>
                  </button>
                </div>

                <div className="flex flex-col min-w-0 pt-0.5">
                  <div className="flex items-center justify-between gap-1">
                    <h4 className="text-xs font-bold text-[#1c1c19] truncate group-hover:text-[#9f3c16] transition-colors">
                      {packItem.title}
                    </h4>
                    {isThisPlaying && (
                      <span className="text-[10px] font-bold text-[#9f3c16] shrink-0 uppercase tracking-wider">
                        Now Playing
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-[#635d59] truncate">
                    {packItem.bpm}
                  </p>
                  <div className="w-full bg-[#e5e2dd] h-1.5 rounded-full mt-1.5 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        isThisPlaying ? 'bg-[#bf542c] animate-pulse' : 'bg-[#9f3c16]'
                      }`}
                      style={{ width: `${packItem.progress}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 5. ARCHIVAL NOTEBOOK INSIGHT CARD */}
      <section className="pb-4">
        <div className="p-4 rounded-2xl bg-[#ebe8e3]/70 border border-[#dec0b7]/40 flex items-center gap-3.5 shadow-2xs">
          <div className="w-11 h-11 rounded-xl bg-[#ffffff] flex items-center justify-center text-[#9f3c16] shrink-0 shadow-sm border border-[#dec0b7]/30">
            <span className="material-symbols-outlined text-2xl">auto_stories</span>
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="font-serif text-sm font-bold text-[#1c1c19] truncate">
              Archival Notebook Insight
            </h4>
            <p className="text-xs text-[#635d59] line-clamp-2 leading-relaxed mt-0.5">
              Your brain consolidates prosody faster during afternoon siesta cycles. 2 review sessions remaining today.
            </p>
          </div>
        </div>
      </section>
      {/* Play History Modal */}
      <PlayHistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        onSelectPack={(packId) => {
          setIsHistoryOpen(false);
          onOpenPack(packId);
        }}
        onPlayPhrase={onPlayPhrase}
      />
    </div>
  );
};
