import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phrase } from '../types';
import { playMasteryChime, playHardRecoil, playPorcelainTap, speakSpanishPhrase, triggerHaptic } from '../utils/audioEngine';
import { triggerSparkleBurst, triggerEnergyRing, triggerFloatingChip } from '../components/SrsFeedback';

interface NowPlayingScreenProps {
  phrase: Phrase;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onPrevious: () => void;
  onNext: () => void;
  playbackSpeed: number;
  onSelectSpeed: (speed: number) => void;
  onOpenQueue: () => void;
  onClose: () => void;
  isFavorite: boolean;
  onToggleFavorite: () => void;
}

export const NowPlayingScreen: React.FC<NowPlayingScreenProps> = ({
  phrase,
  isPlaying,
  onTogglePlay,
  onPrevious,
  onNext,
  playbackSpeed,
  onSelectSpeed,
  onOpenQueue,
  onClose,
  isFavorite,
  onToggleFavorite,
}) => {
  const [openFlyoutTab, setOpenFlyoutTab] = useState<'mnemonic' | 'grammar' | 'phonetics' | null>('mnemonic');
  const [progressPercent, setProgressPercent] = useState(37);
  const [currentTimeSec, setCurrentTimeSec] = useState(14);
  const [selectedRating, setSelectedRating] = useState<'hard' | 'easy' | null>('easy');
  const [isSavedToCodex, setIsSavedToCodex] = useState(false);
  const [currentBeat, setCurrentBeat] = useState(2);
  const [isDraggingY, setIsDraggingY] = useState(false);

  // Rhythm beat tick when playing
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTimeSec((prev) => {
          const next = prev >= phrase.durationSeconds ? 0 : prev + 1;
          setProgressPercent(Math.round((next / phrase.durationSeconds) * 100));
          return next;
        });
        setCurrentBeat((prev) => (prev % 4) + 1);
        playPorcelainTap(1100, 0.05);
      }, 1000 / playbackSpeed);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isPlaying, phrase.durationSeconds, playbackSpeed]);

  const [swipeOffset, setSwipeOffset] = useState<number>(0);
  const [isSwipingCard, setIsSwipingCard] = useState<boolean>(false);
  const [switchDirection, setSwitchDirection] = useState<'next' | 'prev' | null>('next');

  const handleNextTrack = () => {
    triggerHaptic('medium');
    setSwitchDirection('next');
    onNext();
  };

  const handlePreviousTrack = () => {
    triggerHaptic('medium');
    setSwitchDirection('prev');
    onPrevious();
  };

  const toggleTab = (tab: 'mnemonic' | 'grammar' | 'phonetics') => {
    triggerHaptic('phase');
    if (openFlyoutTab === tab) {
      setOpenFlyoutTab(null);
    } else {
      setOpenFlyoutTab(tab);
    }
  };

  const handleRate = (rating: 'hard' | 'easy', e: React.MouseEvent<HTMLButtonElement>) => {
    setSelectedRating(rating);
    const btn = e.currentTarget;
    if (rating === 'easy') {
      playMasteryChime();
      triggerSparkleBurst(btn);
      triggerFloatingChip(btn, '★ Spaced (+4d)', 'bg-[#3a492c] text-[#d6e9c1] border border-[#d6e9c1]/60 shadow-lg');
    } else {
      playHardRecoil();
      triggerEnergyRing(btn);
      triggerFloatingChip(btn, 'Requeued ⚡ 10m', 'bg-[#9f3c16] text-[#ffc9b7] border border-[#ffdbcf]/60 shadow-lg');
    }
  };

  const handlePronounce = () => {
    speakSpanishPhrase(phrase.spanish, playbackSpeed);
  };

  return (
    <motion.div
      drag="y"
      dragConstraints={{ top: 0, bottom: 0 }}
      dragElastic={{ top: 0.05, bottom: 0.85 }}
      dragDirectionLock
      onDragStart={() => setIsDraggingY(true)}
      onDragEnd={(_e, info) => {
        setIsDraggingY(false);
        if (info.offset.y > 100 || info.velocity.y > 450) {
          playPorcelainTap(900);
          onClose();
        }
      }}
      className="fixed inset-0 z-50 bg-[#fcf9f4] flex flex-col select-none overflow-hidden w-full h-full shadow-2xl will-change-transform"
    >
      {/* 1. Top Bar: Draggable Pull-to-Dismiss Handle & Minimal Header */}
      <div className="w-full flex flex-col shrink-0 select-none bg-[#fcf9f4] z-40 relative">
        {/* Tactile Grab Indicator */}
        <div className="w-10 h-1 rounded-full bg-[#dec0b7] mx-auto mt-2 mb-0.5 opacity-80" />
        <header className="flex items-center justify-between px-4 sm:px-6 md:px-8 py-1.5 w-full max-w-5xl mx-auto text-[#1c1c19]">
          <button
            aria-label="Dismiss player"
            onClick={onClose}
            className="w-10 h-10 -ml-1 rounded-full flex items-center justify-center active:scale-90 transition-transform text-[#1c1c19] hover:bg-[#f6f3ee] cursor-pointer"
            type="button"
          >
            <span className="material-symbols-outlined text-2xl">keyboard_arrow_down</span>
          </button>

          <div className="flex flex-col items-center text-center min-w-0 px-2 flex-1">
            <span className="text-[10px] tracking-[0.16em] uppercase text-[#735c53] font-bold">
              PLAYING FROM PLAYLIST
            </span>
            <span className="text-xs sm:text-sm text-[#1c1c19] truncate font-bold mt-0.5 tracking-tight font-serif">
              Café &amp; Mañanas (Vol. ...
            </span>
          </div>

          <button
            aria-label="Track options / Open Queue"
            onClick={onOpenQueue}
            className="w-10 h-10 -mr-1 rounded-full flex items-center justify-center active:scale-90 transition-transform text-[#1c1c19] hover:bg-[#f6f3ee] cursor-pointer"
            title="Open Listening Queue"
            type="button"
          >
            <span className="material-symbols-outlined text-2xl">playlist_play</span>
          </button>
        </header>
      </div>

      {/* Main Container - Responsive Grid (2 columns on md/lg, single column on mobile) */}
      <main className="flex-1 w-full max-w-5xl mx-auto flex flex-col justify-start md:justify-center px-4 sm:px-6 md:px-10 pt-3 sm:pt-5 md:pt-6 pb-6 sm:pb-8 min-h-0 overflow-y-auto scrollbar-none relative z-10">
        <div className="w-full grid grid-cols-1 md:grid-cols-12 md:items-center gap-4 sm:gap-6 md:gap-8 lg:gap-12 xl:gap-16 md:my-auto">
          {/* Left Column: Cover Art & Interactive Immersion Carousel */}
          <div className="md:col-span-5 lg:col-span-5 w-full flex flex-col items-center justify-center relative">
            {/* Directional Swipe Action Cue: Next Track (swiping left) */}
            <motion.div
              animate={{
                opacity: swipeOffset < -25 ? Math.min(1, Math.abs(swipeOffset) / 60) : 0,
                scale: swipeOffset < -25 ? 1 : 0.85,
                x: swipeOffset < -25 ? -10 : 0,
              }}
              transition={{ duration: 0.15 }}
              className="absolute right-1 top-1/2 -translate-y-1/2 z-40 pointer-events-none flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#9f3c16] text-white text-xs font-bold shadow-lg"
            >
              <span>Next</span>
              <span className="material-symbols-outlined text-sm">arrow_forward</span>
            </motion.div>

            {/* Directional Swipe Action Cue: Previous Track (swiping right) */}
            <motion.div
              animate={{
                opacity: swipeOffset > 25 ? Math.min(1, swipeOffset / 60) : 0,
                scale: swipeOffset > 25 ? 1 : 0.85,
                x: swipeOffset > 25 ? 10 : 0,
              }}
              transition={{ duration: 0.15 }}
              className="absolute left-2 top-1/2 -translate-y-1/2 z-40 pointer-events-none flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#3a492c] text-white text-xs font-bold shadow-lg"
            >
              <span className="material-symbols-outlined text-sm">arrow_back</span>
              <span>Prev</span>
            </motion.div>

            {/* Responsive Full-Width Carousel Container */}
            <div className="relative w-full aspect-square max-w-full sm:max-w-md md:max-w-none lg:max-w-[460px] flex items-center justify-center overflow-visible">
              <AnimatePresence initial={false} custom={switchDirection} mode="popLayout">
                <motion.div
                  key={phrase.id}
                  custom={switchDirection}
                  initial={(dir: 'next' | 'prev' | null) => ({
                    x: dir === 'next' ? 240 : -240,
                    opacity: 0.15,
                    scale: 0.9,
                    rotate: dir === 'next' ? 4 : -4,
                  })}
                  animate={{
                    x: 0,
                    opacity: 1,
                    scale: 1,
                    rotate: 0,
                  }}
                  exit={(dir: 'next' | 'prev' | null) => ({
                    x: dir === 'next' ? -240 : 240,
                    opacity: 0.15,
                    scale: 0.9,
                    rotate: dir === 'next' ? -4 : 4,
                  })}
                  transition={{
                    type: 'spring',
                    stiffness: 300,
                    damping: 30,
                    mass: 0.8,
                  }}
                  drag="x"
                  dragConstraints={{ left: 0, right: 0 }}
                  dragElastic={0.45}
                  onDragStart={() => setIsSwipingCard(true)}
                  onDrag={(_e, info) => setSwipeOffset(info.offset.x)}
                  onDragEnd={(_e, info) => {
                    setIsSwipingCard(false);
                    setSwipeOffset(0);
                    if (info.offset.x < -50 || info.velocity.x < -220) {
                      playPorcelainTap(1500);
                      handleNextTrack();
                    } else if (info.offset.x > 50 || info.velocity.x > 220) {
                      playPorcelainTap(1200);
                      handlePreviousTrack();
                    }
                  }}
                  className="relative w-full h-full rounded-2xl sm:rounded-3xl overflow-hidden shadow-xl sm:shadow-2xl border border-[#dec0b7]/40 group bg-[#f0ede9] cursor-grab active:cursor-grabbing touch-pan-y"
                >
                  <img
                    alt={phrase.spanish}
                    className="absolute inset-0 w-full h-full object-cover select-none pointer-events-none"
                    src={phrase.coverImage || 'https://lh3.googleusercontent.com/aida-public/AB6AXuARSyqQjTe5OmRftOyRB6H9s9wCyY5mCYRtT88IO34sB7wGNZV843oE2LUC-Ex7kYotb12IZBze34zwIT2C06XpwvX7UZniovVCMqL9JaI-bgg5YxIVvLEzaVGHDec0yUh5fEaH7Cnb_iqDBRQANjWsgC2ZyyaFmbgDNNj9IKk1SRYua-Usd12teGsvq4_cZQ4vOK5_3udfWubTQSTkK1yGQSdzIcQa4Ax11KMzQZK3n-s_ay_KpnAfPg'}
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = 'https://lh3.googleusercontent.com/aida-public/AB6AXuARSyqQjTe5OmRftOyRB6H9s9wCyY5mCYRtT88IO34sB7wGNZV843oE2LUC-Ex7kYotb12IZBze34zwIT2C06XpwvX7UZniovVCMqL9JaI-bgg5YxIVvLEzaVGHDec0yUh5fEaH7Cnb_iqDBRQANjWsgC2ZyyaFmbgDNNj9IKk1SRYua-Usd12teGsvq4_cZQ4vOK5_3udfWubTQSTkK1yGQSdzIcQa4Ax11KMzQZK3n-s_ay_KpnAfPg';
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/10 to-black/45 pointer-events-none" />

                  {/* Top Trigger Bar: 3 Standalone Floating Pill Buttons */}
                  <div className="absolute top-3 inset-x-0 flex justify-center z-30 px-3 sm:px-4">
                    <div className="flex items-center gap-1.5 sm:gap-2 max-w-full">
                      {/* Mnemonic Pill Trigger */}
                      <motion.button
                        id="pill-mnemonic"
                        whileHover={{ scale: 1.08 }}
                        whileTap={{ scale: 0.93 }}
                        onClick={() => toggleTab('mnemonic')}
                        className={`w-8 h-8 rounded-full text-xs font-bold flex items-center justify-center shadow-lg transition-all cursor-pointer ${
                          openFlyoutTab === 'mnemonic'
                            ? 'bg-[#9f3c16] text-white ring-2 ring-[#ffdbcf]/50 border border-white/40'
                            : 'backdrop-blur-md bg-stone-950/70 border border-white/20 text-white/90 hover:text-white hover:bg-stone-950/80'
                        }`}
                        title="Mnemonic"
                        aria-label="Mnemonic"
                        type="button"
                      >
                        <span className="text-sm leading-none select-none">💡</span>
                      </motion.button>

                      {/* Grammar Pill Trigger */}
                      <motion.button
                        id="pill-grammar"
                        whileHover={{ scale: 1.08 }}
                        whileTap={{ scale: 0.93 }}
                        onClick={() => toggleTab('grammar')}
                        className={`w-8 h-8 rounded-full text-xs font-bold flex items-center justify-center shadow-md transition-all cursor-pointer ${
                          openFlyoutTab === 'grammar'
                            ? 'bg-[#9f3c16] text-white ring-2 ring-[#ffdbcf]/50 border border-white/40'
                            : 'backdrop-blur-md bg-stone-950/70 border border-white/20 text-white/90 hover:text-white hover:bg-stone-950/80'
                        }`}
                        title="Grammar"
                        aria-label="Grammar"
                        type="button"
                      >
                        <span className="text-sm leading-none select-none">📖</span>
                      </motion.button>

                      {/* Phonetics Pill Trigger */}
                      <motion.button
                        id="pill-phonetics"
                        whileHover={{ scale: 1.08 }}
                        whileTap={{ scale: 0.93 }}
                        onClick={() => toggleTab('phonetics')}
                        className={`w-8 h-8 rounded-full text-xs font-bold flex items-center justify-center shadow-md transition-all cursor-pointer ${
                          openFlyoutTab === 'phonetics'
                            ? 'bg-[#9f3c16] text-white ring-2 ring-[#ffdbcf]/50 border border-white/40'
                            : 'backdrop-blur-md bg-stone-950/70 border border-white/20 text-white/90 hover:text-white hover:bg-stone-950/80'
                        }`}
                        title="Phonetics"
                        aria-label="Phonetics"
                        type="button"
                      >
                        <span className="text-sm leading-none select-none">🗣️</span>
                      </motion.button>
                    </div>
                  </div>

                  {/* Bottom Overlay: Audio Cadence & Dialect Marker */}
                  <div className="absolute bottom-3 inset-x-3 sm:inset-x-4 flex items-center justify-between z-10 pointer-events-none text-white/80">
                    <div className="flex items-center gap-1.5 bg-black/45 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/15 text-[11px] font-medium">
                      <span className="material-symbols-outlined text-xs text-[#ffdbcf]">graphic_eq</span>
                      <span>{phrase.meterTag}</span>
                    </div>
                    <div className="flex items-center gap-1 bg-black/45 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/15 text-[11px] font-medium">
                      <span className="text-xs">🇪🇸</span>
                      <span className="text-white/90">{phrase.dialect}</span>
                    </div>
                  </div>

                  {/* Expandable Frosted Glass Flyout / Modal Card with AnimatePresence */}
                  <AnimatePresence mode="wait">
                    {openFlyoutTab && (
                      <motion.div
                        key={openFlyoutTab}
                        initial={{ opacity: 0, y: -10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: -8, scale: 0.95 }}
                        transition={{ type: 'spring', damping: 25, stiffness: 350 }}
                        className="absolute top-14 inset-x-3 sm:inset-x-4 z-20"
                      >
                        <div className="backdrop-blur-xl bg-stone-950/90 border border-white/20 rounded-2xl p-3 shadow-2xl flex flex-col gap-1.5 relative ring-1 ring-black/40 text-white">
                          {/* Flyout Content: Mnemonic Lab */}
                          {openFlyoutTab === 'mnemonic' && (
                            <div className="flex flex-col gap-1.5">
                              <div className="flex items-center justify-between pb-1 border-b border-white/10">
                                <div className="flex items-center gap-1.5 min-w-0">
                                  <span className="text-xs">💡</span>
                                  <span className="text-[11px] text-white font-bold tracking-tight">
                                    {phrase.mnemonic.title}
                                  </span>
                                </div>
                                <span className="px-1.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-[9px] font-bold text-emerald-300 shrink-0">
                                  {phrase.mnemonic.recallPercent || '96% Recall'}
                                </span>
                              </div>
                              <p className="text-[11px] text-white/90 leading-snug pt-0.5">
                                <span className="text-[#ffdbcf] font-semibold">Sensory Trigger: </span>
                                {phrase.mnemonic.description}
                              </p>
                            </div>
                          )}

                          {/* Flyout Content: Grammar Pragmatics */}
                          {openFlyoutTab === 'grammar' && (
                            <div className="flex flex-col gap-1.5">
                              <div className="flex items-center justify-between pb-1 border-b border-white/10">
                                <span className="text-[11px] font-bold text-[#ffdbcf] flex items-center gap-1">
                                  <span>🇪🇸</span> {phrase.grammar.title}
                                </span>
                                <span className="text-[9px] uppercase tracking-wider text-white/60 font-semibold">
                                  Native Norm
                                </span>
                              </div>
                              <div className="text-[10.5px] leading-relaxed text-white/90 pt-0.5">
                                {phrase.grammar.explanation}
                              </div>
                            </div>
                          )}

                          {/* Flyout Content: Phonetics & Syllabic Stress */}
                          {openFlyoutTab === 'phonetics' && (
                            <div className="flex flex-col gap-1.5">
                              <div className="flex items-center justify-between pb-1 border-b border-white/10">
                                <span className="text-[11px] font-bold text-[#d6e9c1] flex items-center gap-1">
                                  <span>〰️</span> Syllabic Stress Contour Map
                                </span>
                                <span className="text-[9px] text-white/60 font-mono tracking-tight">
                                  Liaison ⁀ Active
                                </span>
                              </div>
                              <div className="bg-white/5 rounded-lg p-2 border border-white/10 flex flex-col gap-1">
                                <div className="flex items-center justify-between text-xs font-mono text-[#ffdbcf] tracking-wide">
                                  <span>{phrase.ipa || '[me ˈpo.ne]'}</span>
                                  <span className="text-white/40 text-[10px]">⁀</span>
                                  <span>[uŋ koɾˈta.ðo]</span>
                                </div>
                                <div className="flex items-center justify-between text-[9px] text-white/70">
                                  <span className="flex items-center gap-1">
                                    <span className="w-1.5 h-1.5 rounded-full bg-[#9f3c16]" />
                                    Trochaic downbeat
                                  </span>
                                  <span className="text-white/50">{phrase.phonetics.friction}</span>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>

          {/* Right Column: Audio details, progress, transport & repetition controls */}
          <div className="md:col-span-7 lg:col-span-7 w-full flex flex-col justify-center space-y-2 sm:space-y-3 md:space-y-3.5 lg:space-y-4 max-w-md sm:max-w-lg md:max-w-none mx-auto md:mx-0">
            {/* 3. Phrase Title & Artist Area with Spotify-style Text Slide */}
            <div className="w-full flex items-start justify-between gap-3 pt-1 pb-1 shrink-0">
              <div
                onClick={handlePronounce}
                className="flex flex-col min-w-0 pr-2 flex-1 cursor-pointer group"
              >
                <AnimatePresence initial={false} custom={switchDirection} mode="wait">
                  <motion.div
                    key={phrase.id}
                    custom={switchDirection}
                    initial={(dir: 'next' | 'prev' | null) => ({
                      x: dir === 'next' ? 40 : -40,
                      opacity: 0,
                    })}
                    animate={{
                      x: 0,
                      opacity: 1,
                    }}
                    exit={(dir: 'next' | 'prev' | null) => ({
                      x: dir === 'next' ? -40 : 40,
                      opacity: 0,
                    })}
                    transition={{
                      duration: 0.22,
                      ease: [0.25, 1, 0.5, 1],
                    }}
                  >
                    <h1 className="font-serif text-xl sm:text-2xl md:text-3xl font-bold text-[#1c1c19] leading-snug tracking-tight italic group-hover:text-[#9f3c16] transition-colors break-words">
                      {phrase.spanish}
                    </h1>
                    <p className="text-xs sm:text-sm text-[#786e68] font-sans mt-0.5">
                      {phrase.english}
                    </p>
                    <div className="flex items-center gap-1.5 mt-1 text-[#57423b]">
                      <span className="text-xs font-semibold text-[#1c1c19]">Sara Martín · Clara</span>
                      <span className="material-symbols-outlined text-[#9f3c16] text-[15px] material-symbols-fill">
                        verified
                      </span>
                      <span className="text-[11px] text-[#635d59]">• Madrid Chamberí</span>
                    </div>
                    <div className="mt-1.5 flex items-center">
                      <span className="px-2.5 py-0.5 rounded-full bg-[#f0ede9] text-[11px] font-medium text-[#786e68] inline-flex items-center">
                        {phrase.meterTag}
                      </span>
                    </div>
                  </motion.div>
                </AnimatePresence>
              </div>

              <div className="flex items-center gap-1 shrink-0 pt-0.5">
                <button
                  aria-label="Favorite phrase"
                  onClick={() => {
                    triggerHaptic('light');
                    onToggleFavorite();
                  }}
                  className="w-9 h-9 rounded-full flex items-center justify-center text-[#9f3c16] hover:bg-[#ffdbcf]/40 active:scale-90 transition-all cursor-pointer"
                  type="button"
                >
                  <span className={`material-symbols-outlined text-2xl ${isFavorite ? 'material-symbols-fill' : ''}`}>
                    {isFavorite ? 'favorite' : 'favorite_border'}
                  </span>
                </button>
                <button
                  aria-label="Save to Codex"
                  onClick={() => {
                    setIsSavedToCodex(!isSavedToCodex);
                    playPorcelainTap(1600);
                    triggerHaptic('light');
                  }}
                  className={`w-9 h-9 rounded-full flex items-center justify-center active:scale-90 transition-all cursor-pointer ${
                    isSavedToCodex ? 'text-[#3a492c]' : 'text-[#635d59] hover:text-[#1c1c19]'
                  }`}
                  type="button"
                >
                  <span className={`material-symbols-outlined text-2xl ${isSavedToCodex ? 'material-symbols-fill' : ''}`}>
                    {isSavedToCodex ? 'bookmark' : 'bookmark_border'}
                  </span>
                </button>
              </div>
            </div>

            {/* 4. Tactile Audio Scrubber & Rhythm Track Bar */}
            <div className="w-full flex flex-col space-y-1.5 px-0.5 py-1 shrink-0">
              <div
                className="group relative h-5 flex items-center cursor-pointer touch-none"
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const pct = Math.max(0, Math.min(100, Math.round(((e.clientX - rect.left) / rect.width) * 100)));
                  setProgressPercent(pct);
                  setCurrentTimeSec(Math.round((pct / 100) * phrase.durationSeconds));
                  triggerHaptic('light');
                }}
              >
                <div className="w-full bg-[#e5e2dd] h-1.5 rounded-full overflow-hidden group-hover:h-2 transition-all">
                  <div
                    className="bg-[#9f3c16] h-full rounded-full transition-all duration-150"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
                <div
                  className="absolute w-3.5 h-3.5 rounded-full bg-[#9f3c16] shadow-md border-2 border-white pointer-events-none transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ left: `${progressPercent}%` }}
                />
              </div>
              <div className="flex justify-between items-center text-[11px] text-[#8a726a] font-mono px-0.5">
                <span>0:{currentTimeSec < 10 ? `0${currentTimeSec}` : currentTimeSec}</span>
                <span>0:{phrase.durationSeconds < 10 ? `0${phrase.durationSeconds}` : phrase.durationSeconds}</span>
              </div>
            </div>

            {/* 5. Primary Playback Deck (Spotify Transport Style) */}
            <div className="w-full flex items-center justify-between sm:justify-around md:justify-between px-1 sm:px-4 md:px-0 lg:px-4 py-0.5 sm:py-1 shrink-0">
              {/* Shuffle Reps */}
              <motion.button
                whileHover={{ scale: 1.08 }}
                whileTap={{ scale: 0.92 }}
                aria-label="Shuffle drills"
                onClick={() => {
                  playPorcelainTap(1400);
                  triggerHaptic('selection');
                  onPrevious();
                }}
                className="w-11 h-11 rounded-full flex items-center justify-center text-[#635d59] hover:text-[#1c1c19] hover:bg-[#f6f3ee] transition-colors cursor-pointer"
                type="button"
              >
                <span className="material-symbols-outlined text-2xl">shuffle</span>
              </motion.button>

              {/* Previous Phrase */}
              <motion.button
                whileHover={{ scale: 1.08 }}
                whileTap={{ scale: 0.92 }}
                aria-label="Previous phrase"
                onClick={handlePreviousTrack}
                className="w-11 h-11 rounded-full flex items-center justify-center text-[#1c1c19] transition-colors hover:bg-[#f6f3ee] cursor-pointer"
                type="button"
              >
                <span className="material-symbols-outlined text-3xl material-symbols-fill">
                  skip_previous
                </span>
              </motion.button>

              {/* Primary Big Play/Pause Button */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.92 }}
                aria-label={isPlaying ? 'Pause drill playback' : 'Start drill playback'}
                onClick={() => {
                  triggerHaptic('medium');
                  onTogglePlay();
                }}
                className="w-13 h-13 sm:w-16 sm:h-16 md:w-14 md:h-14 lg:w-16 lg:h-16 rounded-full bg-[#9f3c16] hover:bg-[#883313] text-white flex items-center justify-center shadow-[0_6px_20px_rgba(191,84,44,0.35)] relative overflow-hidden cursor-pointer active:scale-95 transition-all shrink-0"
                type="button"
              >
                {isPlaying && (
                  <motion.span
                    initial={{ scale: 0.8, opacity: 0.6 }}
                    animate={{ scale: 1.4, opacity: 0 }}
                    transition={{ repeat: Infinity, duration: 1.4, ease: 'easeOut' }}
                    className="absolute inset-0 rounded-full border-2 border-white/50 pointer-events-none"
                  />
                )}
                <span className="material-symbols-outlined text-3xl sm:text-4xl material-symbols-fill relative z-10">
                  {isPlaying ? 'pause' : 'play_arrow'}
                </span>
              </motion.button>

              {/* Next Phrase */}
              <motion.button
                whileHover={{ scale: 1.08 }}
                whileTap={{ scale: 0.92 }}
                aria-label="Next phrase"
                onClick={handleNextTrack}
                className="w-11 h-11 rounded-full flex items-center justify-center text-[#1c1c19] transition-colors hover:bg-[#f6f3ee] cursor-pointer"
                type="button"
              >
                <span className="material-symbols-outlined text-3xl material-symbols-fill">
                  skip_next
                </span>
              </motion.button>

              {/* Continuous Loop Toggle */}
              <motion.button
                whileHover={{ scale: 1.08 }}
                whileTap={{ scale: 0.92 }}
                aria-label="Continuous cadence loop active 3 times"
                onClick={() => {
                  triggerHaptic('light');
                  handlePronounce();
                }}
                className="w-11 h-11 rounded-full flex items-center justify-center relative text-[#9f3c16] hover:bg-[#ffdbcf]/30 transition-colors cursor-pointer"
                title="Loop Cadence 3x"
                type="button"
              >
                <span className="material-symbols-outlined text-2xl">repeat</span>
                <span className="absolute top-1.5 right-1 text-[9px] font-black bg-[#ffdbcf] text-[#822701] rounded-full px-1 leading-tight ring-1 ring-white">
                  3×
                </span>
              </motion.button>
            </div>

            {/* 6. Spaced Repetition SRS Segmented Rating Capsule */}
            <div className="w-full flex items-center justify-center shrink-0 pt-0.5 sm:pt-1">
              <div className="inline-flex items-center p-0.5 sm:p-1 bg-[#f6f3ee] border border-[#dec0b7]/50 rounded-full shadow-2xs">
                {/* Hard Option */}
                <motion.button
                  whileTap={{ scale: 0.92 }}
                  onClick={(e) => handleRate('hard', e)}
                  className={`px-3 sm:px-4 py-1 sm:py-1.5 rounded-full transition-all flex items-center gap-1 sm:gap-1.5 cursor-pointer ${
                    selectedRating === 'hard'
                      ? 'bg-[#ffdad6] text-[#93000a] font-bold ring-1 ring-[#ba1a1a]/25 shadow-xs'
                      : 'text-[#57423b] hover:text-[#1c1c19]'
                  }`}
                  type="button"
                >
                  <span className="material-symbols-outlined text-sm sm:text-base text-[#ba1a1a]">
                    close
                  </span>
                  <span className="text-[11px] sm:text-xs font-semibold whitespace-nowrap">Hard (10m)</span>
                </motion.button>

                {/* Easy Option */}
                <motion.button
                  whileTap={{ scale: 0.92 }}
                  onClick={(e) => handleRate('easy', e)}
                  className={`px-3 sm:px-4 py-1 sm:py-1.5 rounded-full transition-all flex items-center gap-1 sm:gap-1.5 cursor-pointer ${
                    selectedRating === 'easy'
                      ? 'bg-[#d6e9c1] text-[#111f07] font-bold shadow-xs ring-1 ring-[#3a492c]/25'
                      : 'text-[#57423b] hover:text-[#1c1c19]'
                  }`}
                  type="button"
                >
                  <span className="material-symbols-outlined text-sm sm:text-base text-[#3a492c] material-symbols-fill">
                    check
                  </span>
                  <span className="text-[11px] sm:text-xs font-semibold whitespace-nowrap">Easy (+4d)</span>
                </motion.button>
              </div>
            </div>

            {/* 7. Tactile Speed & Cadence Multipliers */}
            <div className="w-full flex flex-wrap items-center justify-center gap-1.5 sm:gap-2 pt-0.5 sm:pt-1 shrink-0 pb-1 sm:pb-2">
              <button
                onClick={() => {
                  triggerHaptic('selection');
                  onSelectSpeed(0.8);
                }}
                className={`px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full border text-[11px] sm:text-xs font-medium active:scale-95 transition-colors cursor-pointer whitespace-nowrap ${
                  playbackSpeed === 0.8
                    ? 'bg-[#9f3c16] text-white border-[#9f3c16] font-bold ring-2 ring-[#ffdbcf]'
                    : 'bg-[#f6f3ee] border-[#dec0b7]/30 text-[#57423b] hover:bg-[#f0ede9]'
                }`}
                type="button"
              >
                0.8x Slow
              </button>
              <button
                onClick={() => {
                  triggerHaptic('selection');
                  onSelectSpeed(1.0);
                }}
                className={`px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full border text-[11px] sm:text-xs font-medium active:scale-95 transition-colors cursor-pointer whitespace-nowrap ${
                  playbackSpeed === 1.0
                    ? 'bg-[#9f3c16] text-white border-[#9f3c16] font-bold ring-2 ring-[#ffdbcf]'
                    : 'bg-[#f6f3ee] border-[#dec0b7]/30 text-[#57423b] hover:bg-[#f0ede9]'
                }`}
                type="button"
              >
                1.0x Normal
              </button>
              <button
                onClick={() => {
                  triggerHaptic('selection');
                  onSelectSpeed(1.25);
                }}
                className={`px-3 sm:px-3.5 py-1 sm:py-1.5 rounded-full border text-[11px] sm:text-xs font-bold active:scale-95 transition-colors cursor-pointer whitespace-nowrap ${
                  playbackSpeed === 1.25
                    ? 'bg-[#9f3c16] text-white border-[#9f3c16] shadow-xs ring-2 ring-[#ffdbcf]'
                    : 'bg-[#f6f3ee] border-[#dec0b7]/30 text-[#57423b] hover:bg-[#f0ede9]'
                }`}
                type="button"
              >
                1.25x Street Speed
              </button>
            </div>
          </div>
        </div>
      </main>
    </motion.div>
  );
};
