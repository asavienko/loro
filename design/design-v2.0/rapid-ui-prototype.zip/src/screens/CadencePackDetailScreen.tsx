import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CadencePack, Phrase } from '../types';
import {
  SrsDockCapsule,
  triggerSparkleBurst,
  triggerEnergyRing,
  triggerFloatingChip,
} from '../components/SrsFeedback';
import { MiniPlayer } from '../components/MiniPlayer';
import {
  playPorcelainTap,
  speakSpanishPhrase,
  playMasteryChime,
  playHardRecoil,
  triggerHaptic,
} from '../utils/audioEngine';

interface CadencePackDetailScreenProps {
  pack: CadencePack;
  currentPhrase: Phrase;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onSelectPhrase: (phrase: Phrase) => void;
  onNextPhrase: () => void;
  onPreviousPhrase?: () => void;
  playbackSpeed: number;
  onToggleSpeed: () => void;
  onOpenPlayer: () => void;
  onBack: () => void;
}

export const CadencePackDetailScreen: React.FC<CadencePackDetailScreenProps> = ({
  pack,
  currentPhrase,
  isPlaying,
  onTogglePlay,
  onSelectPhrase,
  onNextPhrase,
  onPreviousPhrase,
  playbackSpeed,
  onToggleSpeed,
  onOpenPlayer,
  onBack,
}) => {
  const [openDrawerId, setOpenDrawerId] = useState<string | null>('phrase-4'); // Phrase 4 expanded by default as in screenshot
  const [activeTabs, setActiveTabs] = useState<Record<string, 'mnemonic' | 'grammar' | 'phonetics'>>({
    'phrase-1': 'mnemonic',
    'phrase-2': 'mnemonic',
    'phrase-3': 'mnemonic',
    'phrase-4': 'mnemonic',
    'phrase-5': 'mnemonic',
    'phrase-6': 'mnemonic',
  });
  const [isFavorite, setIsFavorite] = useState(true);
  const [isShuffle, setIsShuffle] = useState(false);
  const [isSpacedIntervalActive, setIsSpacedIntervalActive] = useState(true);
  const [isCopiedRecently, setIsCopiedRecently] = useState(false);
  const isSharingRef = useRef(false);
  const [activeDrillSpeechId, setActiveDrillSpeechId] = useState<string | null>(null);
  const [phraseReviewStatus, setPhraseReviewStatus] = useState<Record<string, 'mastered' | 'review'>>({});

  const toggleDrawer = (phraseId: string) => {
    setOpenDrawerId((prev) => (prev === phraseId ? null : phraseId));
  };

  const handleTabSwitch = (phraseId: string, tab: 'mnemonic' | 'grammar' | 'phonetics') => {
    setActiveTabs((prev) => ({ ...prev, [phraseId]: tab }));
  };

  const handleSwipeCard = (phrase: Phrase, direction: 'mastered' | 'review', targetEl?: HTMLElement) => {
    setPhraseReviewStatus((prev) => ({ ...prev, [phrase.id]: direction }));
    if (direction === 'mastered') {
      playMasteryChime();
      if (targetEl) {
        triggerSparkleBurst(targetEl);
        triggerFloatingChip(targetEl, '★ Mastered (+4d)', 'bg-[#3a492c] text-[#d6e9c1] border border-[#d6e9c1]/60 shadow-lg');
      }
    } else {
      playHardRecoil();
      if (targetEl) {
        triggerEnergyRing(targetEl);
        triggerFloatingChip(targetEl, 'Requeued ⚡ 10m', 'bg-[#9f3c16] text-[#ffc9b7] border border-[#ffdbcf]/60 shadow-lg');
      }
    }
  };

  const handleAudioEcho = (phrase: Phrase, e: React.MouseEvent) => {
    e.stopPropagation();
    playPorcelainTap(1300);
    setActiveDrillSpeechId(phrase.id);
    onSelectPhrase(phrase);
    speakSpanishPhrase(phrase.spanish, playbackSpeed, () => {
      setActiveDrillSpeechId(null);
    });
  };

  const handleShare = async (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    if (isSharingRef.current) return;

    const btn = e.currentTarget;
    playPorcelainTap(1500);
    triggerHaptic('light');

    if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
      isSharingRef.current = true;
      try {
        await navigator.share({
          title: pack.title,
          text: pack.subtitle,
          url: window.location.href,
        });
      } catch (err: unknown) {
        // DOMException AbortError is thrown when user cancels the share dialog
        // InvalidStateError is thrown when an earlier share call is still pending
        const isCancellation =
          (err instanceof DOMException && (err.name === 'AbortError' || err.name === 'InvalidStateError')) ||
          (err instanceof Error && (err.message.includes('canceled') || err.message.includes('not yet completed')));

        if (!isCancellation) {
          // Fallback to clipboard if share rejected for security/iframe permission reasons
          try {
            if (navigator.clipboard && navigator.clipboard.writeText) {
              await navigator.clipboard.writeText(window.location.href);
              triggerFloatingChip(btn, 'Link Copied! 📋', 'bg-[#3a492c] text-[#d6e9c1] border border-[#d6e9c1]/60 shadow-lg');
              setIsCopiedRecently(true);
              setTimeout(() => setIsCopiedRecently(false), 2200);
            }
          } catch {
            // Silently ignore clipboard write failures
          }
        }
      } finally {
        isSharingRef.current = false;
      }
    } else {
      // Fallback if Web Share API is not available
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(window.location.href);
          triggerFloatingChip(btn, 'Link Copied! 📋', 'bg-[#3a492c] text-[#d6e9c1] border border-[#d6e9c1]/60 shadow-lg');
          setIsCopiedRecently(true);
          setTimeout(() => setIsCopiedRecently(false), 2200);
        }
      } catch {
        // Silently ignore clipboard write failures
      }
    }
  };

  return (
    <div className="flex flex-col w-full pb-44 bg-[#fcf9f4] min-h-screen select-none">
      {/* 1. Hero / Album Header Section */}
      <div className="w-full px-4 sm:px-6 lg:px-8 pt-3 pb-6 flex flex-col gap-4 bg-[#f6f3ee] border-b border-[#ebe8e3]">
        <div className="max-w-5xl mx-auto w-full flex flex-col gap-4">
          {/* Pack Artwork & Info */}
          <div className="flex items-start sm:items-center gap-4 sm:gap-6">
            {/* Vinyl-style square sleeve artwork */}
            <div className="relative w-28 h-28 sm:w-36 sm:h-36 md:w-40 md:h-40 shrink-0 rounded-2xl overflow-hidden shadow-md bg-[#f0ede9] border border-[#dec0b7]/40">
              <img
                className="w-full h-full object-cover"
                alt={pack.title}
                src={pack.coverImage}
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-1.5 right-1.5 bg-[#7f2500]/90 text-white rounded-full px-2 py-0.5 flex items-center gap-0.5 shadow-sm">
                <span className="material-symbols-outlined text-xs">graphic_eq</span>
                <span className="text-[10px] font-bold tracking-wider">{pack.vol}</span>
              </div>
            </div>

            {/* Meta info */}
            <div className="flex flex-col min-w-0 justify-center flex-1">
              <div className="flex items-center gap-1.5 mb-1">
                <span className="px-2 py-0.5 rounded-full bg-[#eae1db] text-[#4b4642] text-[10px] font-bold uppercase tracking-wider">
                  ACOUSTIC CADENCE
                </span>
              </div>
              <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl text-[#1c1c19] leading-tight font-bold truncate">
                {pack.title}
              </h2>
              <p className="text-xs sm:text-sm text-[#635d59] line-clamp-2 mt-0.5">
                {pack.subtitle}
              </p>
              <p className="text-xs sm:text-sm text-[#8a726a] mt-1.5 flex items-center gap-1 font-medium">
                <span className="material-symbols-outlined text-sm sm:text-base text-[#9f3c16]">
                  record_voice_over
                </span>
                <span>{pack.speakers}</span>
              </p>
            </div>
          </div>

          {/* Extended Stats bar */}
          <div className="flex items-center justify-between py-2 px-3 sm:px-4 rounded-xl bg-[#f0ede9]/80 text-[#635d59] text-xs sm:text-sm font-semibold border border-[#dec0b7]/30">
            <span>{pack.phrasesCount} Earworms • {pack.runDuration}</span>
            <span className="flex items-center gap-1">
              <span className="material-symbols-outlined text-sm sm:text-base text-[#3a492c]">
                groups
              </span>
              <span>{pack.scholarsCount}</span>
            </span>
          </div>

          {/* Quick Action Utilities */}
          <div className="flex items-center justify-between pt-0.5">
            <div className="flex items-center gap-2">
              {/* Add to library heart */}
              <button
                aria-label="Favorite playlist"
                onClick={() => {
                  playPorcelainTap(1500);
                  triggerHaptic('light');
                  setIsFavorite(!isFavorite);
                }}
                className={`w-9 h-9 rounded-full bg-[#f0ede9] border border-[#dec0b7]/30 flex items-center justify-center active:scale-95 transition-transform ${
                  isFavorite ? 'text-[#9f3c16]' : 'text-[#8a726a]'
                }`}
                type="button"
              >
                <span className={`material-symbols-outlined text-lg ${isFavorite ? 'material-symbols-fill' : ''}`}>
                  favorite
                </span>
              </button>

              {/* Shuffle button next to like button */}
              <button
                aria-label="Shuffle playback"
                onClick={() => {
                  playPorcelainTap(1400);
                  triggerHaptic('selection');
                  setIsShuffle(!isShuffle);
                  if (onNextPhrase) onNextPhrase();
                }}
                className={`w-9 h-9 rounded-full border border-[#dec0b7]/30 flex items-center justify-center active:scale-95 transition-transform ${
                  isShuffle
                    ? 'bg-[#ffdbcf] text-[#9f3c16] border-[#9f3c16]/40 shadow-xs'
                    : 'bg-[#f0ede9] text-[#57423b] hover:text-[#1c1c19]'
                }`}
                type="button"
                title="Shuffle"
              >
                <span className="material-symbols-outlined text-lg">shuffle</span>
              </button>

              {/* Share */}
              <button
                aria-label="Share"
                onClick={handleShare}
                className="w-9 h-9 rounded-full bg-[#f0ede9] border border-[#dec0b7]/30 flex items-center justify-center text-[#57423b] hover:text-[#1c1c19] active:scale-95 transition-transform"
                type="button"
                title={isCopiedRecently ? 'Link copied to clipboard' : 'Share playlist'}
              >
                <span className={`material-symbols-outlined text-lg ${isCopiedRecently ? 'text-[#3a492c]' : ''}`}>
                  {isCopiedRecently ? 'check' : 'share'}
                </span>
              </button>
            </div>

            {/* Overflow options */}
            <button
              aria-label="More options"
              onClick={onOpenPlayer}
              className="w-9 h-9 rounded-full bg-[#f0ede9] border border-[#dec0b7]/30 flex items-center justify-center text-[#57423b] active:scale-95 transition-transform"
              type="button"
            >
              <span className="material-symbols-outlined text-lg">open_in_full</span>
            </button>
          </div>

          {/* Playback Control Row */}
          <div className="h-14 sm:h-16 flex items-center justify-between gap-2 sm:gap-3.5 pt-1 w-full overflow-hidden">
            <div className="flex items-center gap-2 sm:gap-3 shrink min-w-0">
              {/* Main Play Action CTA */}
              <button
                aria-label="Play cadence deck"
                onClick={onTogglePlay}
                className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-[#9f3c16] hover:bg-[#bf542c] text-white flex items-center justify-center shadow-md active:scale-95 transition-transform duration-150 shrink-0 cursor-pointer"
                type="button"
              >
                <span className="material-symbols-outlined text-2xl sm:text-3xl material-symbols-fill select-none pointer-events-none">
                  {isPlaying ? 'pause' : 'play_arrow'}
                </span>
              </button>

              {/* Spaced Interval Switch (ON / OFF States) */}
              <button
                role="switch"
                aria-checked={isSpacedIntervalActive}
                aria-label={`Spaced interval repetitions: ${isSpacedIntervalActive ? 'On' : 'Off'}`}
                onClick={(e) => {
                  const nextState = !isSpacedIntervalActive;
                  setIsSpacedIntervalActive(nextState);
                  if (nextState) {
                    playPorcelainTap(1600);
                    triggerHaptic('medium');
                    triggerFloatingChip(
                      e.currentTarget,
                      '⚡ Spaced Interval: ON',
                      'bg-[#3a492c]/95 text-[#d6e9c1] border border-[#d6e9c1]/60'
                    );
                  } else {
                    playPorcelainTap(1100);
                    triggerHaptic('light');
                    triggerFloatingChip(
                      e.currentTarget,
                      'Spaced Interval: OFF',
                      'bg-[#57423b]/95 text-[#fcf9f4] border border-[#dec0b7]/40'
                    );
                  }
                }}
                className={`h-11 sm:h-12 px-3 sm:px-4 rounded-full flex items-center gap-1.5 sm:gap-2 shadow-2xs active:scale-95 transition-all duration-150 border shrink min-w-0 cursor-pointer select-none ${
                  isSpacedIntervalActive
                    ? 'bg-[#ffdbcf]/85 hover:bg-[#ffdbcf] text-[#390c00] border-[#9f3c16]/30'
                    : 'bg-[#f0ede9] hover:bg-[#e7e4de] text-[#786e68] border-[#dec0b7]/40'
                }`}
                type="button"
              >
                <span
                  className={`material-symbols-outlined text-base sm:text-lg shrink-0 transition-colors ${
                    isSpacedIntervalActive ? 'text-[#9f3c16] material-symbols-fill' : 'text-[#8a726a]'
                  }`}
                >
                  hourglass_top
                </span>
                <span className="truncate text-xs sm:text-sm font-bold">Spaced Interval</span>
              </button>
            </div>

            {/* Dialect / Acoustic Tuning Chip */}
            <button
              aria-label={`Playback speed: ${playbackSpeed}x`}
              onClick={onToggleSpeed}
              className="h-11 sm:h-12 flex items-center justify-center gap-1.5 px-3 sm:px-4 rounded-full bg-[#f0ede9] hover:bg-[#e6e2dc] border border-[#dec0b7]/40 text-[#57423b] text-xs sm:text-sm font-semibold active:scale-95 transition-colors duration-150 shrink-0 cursor-pointer select-none ml-1 sm:ml-0"
              type="button"
            >
              <span className="material-symbols-outlined text-sm sm:text-base text-[#9f3c16] shrink-0">speed</span>
              <span className="hidden sm:inline text-[#8a726a] font-normal">Madrid •</span>
              <span className="font-bold tabular-nums text-[#1c1c19] min-w-[32px] text-center">{playbackSpeed}x</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Tracklist Section */}
      <div className="w-full px-4 sm:px-6 lg:px-8 py-4 max-w-5xl mx-auto flex flex-col gap-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-serif text-xl font-bold text-[#1c1c19]">Cadence Deck</h3>
            <span className="px-2.5 py-0.5 rounded-full bg-[#f0ede9] text-xs font-semibold text-[#635d59]">
              Acoustic Drills
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button className="text-xs font-bold text-[#9f3c16] flex items-center gap-0.5 hover:underline cursor-pointer" type="button">
              <span>Sort by Meter</span>
              <span className="material-symbols-outlined text-sm">unfold_more</span>
            </button>
          </div>
        </div>

        {/* Tracklist items container */}
        <div className="flex flex-col gap-3" id="playlist-container">
          {pack.phrases.map((phrase, idx) => {
            const isCurrentlyPlaying = isPlaying && currentPhrase.id === phrase.id;
            const isSelected = currentPhrase.id === phrase.id;
            const isOpen = openDrawerId === phrase.id;
            const activeTab = activeTabs[phrase.id] || 'mnemonic';
            const userStatus = phraseReviewStatus[phrase.id];
            const isMastered = userStatus === 'mastered' || (!userStatus && phrase.alertTag?.type === 'mastered');
            const isReview = userStatus === 'review';

            return (
              <div
                key={phrase.id}
                className="relative rounded-2xl"
              >
                {/* Phrase Card (Static, No Swipe Gestures) */}
                <div
                  id={`phrase-card-${phrase.id}`}
                  className={`phrase-card relative z-10 w-full rounded-2xl bg-[#ffffff] p-4 flex flex-col gap-2.5 shadow-sm transition-all duration-200 border ${
                    isSelected
                      ? 'border-[#9f3c16]/70 ring-1 ring-[#ffdbcf]/50 shadow-md'
                      : 'border-[#dec0b7]/40 hover:border-[#9f3c16]/30'
                  }`}
                >
                  {/* Phrase Header Row */}
                  <div className="flex items-start justify-between gap-3">
                    {/* Left: Audio eq / Track number + Title */}
                    <div
                      onClick={() => {
                        onSelectPhrase(phrase);
                        toggleDrawer(phrase.id);
                      }}
                      className="flex items-start gap-3 min-w-0 flex-1 cursor-pointer"
                    >
                      {/* Badge or Track number */}
                      {isSelected ? (
                        <div className="w-7 h-7 shrink-0 rounded-full bg-[#ffdbcf] flex items-center justify-center text-[#9f3c16] mt-0.5">
                          <div className="flex items-end gap-0.5 h-3.5">
                            <span className="w-0.5 bg-[#9f3c16] rounded-full eq-bar-1" />
                            <span className="w-0.5 bg-[#9f3c16] rounded-full eq-bar-2" />
                            <span className="w-0.5 bg-[#9f3c16] rounded-full eq-bar-3" />
                          </div>
                        </div>
                      ) : isMastered ? (
                        <span className="w-7 h-7 shrink-0 rounded-full bg-[#d6e9c1] text-[#111f07] flex items-center justify-center mt-0.5 font-bold text-xs">
                          <span className="material-symbols-outlined text-sm material-symbols-fill">
                            check
                          </span>
                        </span>
                      ) : isReview ? (
                        <span className="w-7 h-7 shrink-0 rounded-full bg-[#ffdbcf] text-[#822701] flex items-center justify-center mt-0.5 font-bold text-xs">
                          <span className="material-symbols-outlined text-sm">
                            replay
                          </span>
                        </span>
                      ) : (
                        <span className="w-7 h-7 shrink-0 rounded-full bg-[#f0ede9] text-[#635d59] flex items-center justify-center text-xs font-bold mt-0.5">
                          {phrase.trackNumber}
                        </span>
                      )}

                      {/* Content Details */}
                      <div className="flex flex-col min-w-0">
                        <div className="flex flex-wrap items-center gap-1.5 mb-1">
                          {isSelected && (
                            <span className="px-2 py-0.5 rounded-full bg-[#ffdbcf] text-[#9f3c16] text-[10px] font-bold">
                              PLAYING
                            </span>
                          )}
                          {isMastered && !isSelected && (
                            <span className="px-2 py-0.5 rounded-full bg-[#d6e9c1] text-[#111f07] text-[10px] font-bold">
                              MASTERED • +4d
                            </span>
                          )}
                          {isReview && !isSelected && (
                            <span className="px-2 py-0.5 rounded-full bg-[#ffdbcf] text-[#822701] text-[10px] font-bold">
                              DUE SOON • 10m
                            </span>
                          )}
                          {!isMastered && !isReview && phrase.alertTag && phrase.alertTag.type !== 'normal' && !isSelected && (
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                phrase.alertTag.type === 'mastered'
                                  ? 'bg-[#d6e9c1] text-[#111f07]'
                                  : phrase.alertTag.type === 'urgent'
                                  ? 'bg-[#ffdbcf] text-[#822701]'
                                  : 'bg-[#ffdad6] text-[#ba1a1a]'
                              }`}
                            >
                              {phrase.alertTag.label}
                            </span>
                          )}
                        <span className="px-2 py-0.5 rounded-full bg-[#f0ede9] text-[#635d59] text-[10px] font-medium">
                          {phrase.categoryTag}
                        </span>
                        <span className="text-[10px] text-[#8a726a] font-medium">
                          {phrase.meterTag}
                        </span>
                      </div>

                      <h4 className="font-serif text-base text-[#1c1c19] tracking-tight leading-snug font-semibold italic">
                        {phrase.spanish}
                      </h4>
                      <p className="text-xs text-[#9f3c16] font-mono mt-0.5 font-medium">
                        {phrase.phonetic}
                      </p>
                      <p className="text-xs text-[#635d59] italic mt-0.5">
                        "{phrase.english}"
                      </p>
                    </div>
                  </div>

                  {/* Trailing actions */}
                  <div className="relative flex flex-col items-end gap-2 shrink-0">
                    <button
                      aria-label="Echo drill playback"
                      onClick={(e) => handleAudioEcho(phrase, e)}
                      className={`w-10 h-10 rounded-full flex items-center justify-center active:scale-90 transition-transform shadow-2xs ${
                        activeDrillSpeechId === phrase.id || isCurrentlyPlaying
                          ? 'bg-[#9f3c16] text-white'
                          : 'bg-[#f6f3ee] text-[#9f3c16] hover:bg-[#ffdbcf]'
                      }`}
                      type="button"
                    >
                      <span className="material-symbols-outlined text-lg material-symbols-fill">
                        volume_up
                      </span>
                    </button>
                    <button
                      aria-label="Toggle notes"
                      onClick={() => toggleDrawer(phrase.id)}
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-[#635d59] hover:text-[#1c1c19] hover:bg-[#f6f3ee] transition-transform duration-200 ${
                        isOpen ? 'rotate-180' : ''
                      }`}
                      type="button"
                    >
                      <span className="material-symbols-outlined text-xl">expand_more</span>
                    </button>
                  </div>
                </div>

                {/* Retention Progress Bar Tray */}
                <div className="w-full bg-[#f6f3ee] rounded-xl p-2.5 flex items-center justify-between gap-3 mt-1 border border-[#dec0b7]/25">
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    <span
                      className={`text-[11px] font-semibold shrink-0 ${
                        phrase.retentionPercent >= 90
                          ? 'text-[#3a492c]'
                          : phrase.retentionPercent < 50
                          ? 'text-[#ba1a1a]'
                          : 'text-[#9f3c16]'
                      }`}
                    >
                      {phrase.retentionStatus}
                    </span>
                    <div className="w-full h-1.5 bg-[#e5e2dd] rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          phrase.retentionPercent >= 90
                            ? 'bg-[#3a492c]'
                            : phrase.retentionPercent < 50
                            ? 'bg-[#ba1a1a]'
                            : 'bg-[#9f3c16]'
                        }`}
                        style={{ width: `${phrase.retentionPercent}%` }}
                      />
                    </div>
                  </div>
                  <span className="text-[11px] text-[#635d59] shrink-0 font-medium flex items-center gap-0.5">
                    {phrase.rank}
                  </span>
                </div>

                {/* TACTILE IN-CARD CONTEXT DRAWER (Minimalistic & Responsive) */}
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      key="drawer-panel"
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
                      className="w-full pt-3 mt-2 border-t border-[#f0ede9] flex flex-col gap-3 overflow-hidden"
                    >
                      {/* Minimalist Segmented Tab Navigation */}
                      <div
                        role="tablist"
                        aria-label="Phrase drill perspectives"
                        className="grid grid-cols-3 gap-1 p-1 bg-[#f4f0ea]/90 rounded-xl sm:rounded-2xl border border-[#ebe7e0]/60 w-full"
                      >
                        <button
                          id={`tab-mnemonic-${phrase.id}`}
                          role="tab"
                          aria-label="Mnemonic"
                          title="Mnemonic"
                          aria-selected={activeTab === 'mnemonic'}
                          onClick={() => {
                            playPorcelainTap(1500);
                            triggerHaptic('selection');
                            handleTabSwitch(phrase.id, 'mnemonic');
                          }}
                          className={`w-full min-w-0 h-9 sm:h-8.5 rounded-lg sm:rounded-xl flex items-center justify-center transition-all active:scale-[0.98] cursor-pointer ${
                            activeTab === 'mnemonic'
                              ? 'bg-white text-[#1c1c19] font-bold shadow-2xs'
                              : 'text-[#635d59] font-medium hover:text-[#1c1c19] hover:bg-white/40'
                          }`}
                          type="button"
                        >
                          <span className="material-symbols-outlined text-[17px] sm:text-[18px] shrink-0">psychology_alt</span>
                        </button>

                        <button
                          id={`tab-grammar-${phrase.id}`}
                          role="tab"
                          aria-label="Grammar"
                          title="Grammar"
                          aria-selected={activeTab === 'grammar'}
                          onClick={() => {
                            playPorcelainTap(1500);
                            triggerHaptic('selection');
                            handleTabSwitch(phrase.id, 'grammar');
                          }}
                          className={`w-full min-w-0 h-9 sm:h-8.5 rounded-lg sm:rounded-xl flex items-center justify-center transition-all active:scale-[0.98] cursor-pointer ${
                            activeTab === 'grammar'
                              ? 'bg-white text-[#1c1c19] font-bold shadow-2xs'
                              : 'text-[#635d59] font-medium hover:text-[#1c1c19] hover:bg-white/40'
                          }`}
                          type="button"
                        >
                          <span className="material-symbols-outlined text-[17px] sm:text-[18px] shrink-0">account_tree</span>
                        </button>

                        <button
                          id={`tab-phonetics-${phrase.id}`}
                          role="tab"
                          aria-label="Phonetics"
                          title="Phonetics"
                          aria-selected={activeTab === 'phonetics'}
                          onClick={() => {
                            playPorcelainTap(1500);
                            triggerHaptic('selection');
                            handleTabSwitch(phrase.id, 'phonetics');
                          }}
                          className={`w-full min-w-0 h-9 sm:h-8.5 rounded-lg sm:rounded-xl flex items-center justify-center transition-all active:scale-[0.98] cursor-pointer ${
                            activeTab === 'phonetics'
                              ? 'bg-white text-[#1c1c19] font-bold shadow-2xs'
                              : 'text-[#635d59] font-medium hover:text-[#1c1c19] hover:bg-white/40'
                          }`}
                          type="button"
                        >
                          <span className="material-symbols-outlined text-[17px] sm:text-[18px] shrink-0">graphic_eq</span>
                        </button>
                      </div>

                      {/* Tab Content Area */}
                      <AnimatePresence mode="wait">
                        {/* Tab 1: Mnemonic */}
                        {activeTab === 'mnemonic' && (
                          <motion.div
                            key="tab-mnemonic"
                            initial={{ opacity: 0, y: 3 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -3 }}
                            transition={{ duration: 0.15 }}
                            className="flex flex-col gap-2.5 px-0.5"
                          >
                            <div className="flex flex-wrap items-center justify-between gap-1.5">
                              <span className="text-xs font-semibold text-[#1c1c19] flex items-center gap-1.5">
                                <span className="material-symbols-outlined text-sm text-[#9f3c16]">
                                  {phrase.mnemonic.icon}
                                </span>
                                {phrase.mnemonic.title}
                              </span>
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#f4f0ea] text-[#635d59] font-mono font-medium">
                                {phrase.mnemonic.tag}
                              </span>
                            </div>

                            <p className="text-xs text-[#57524e] leading-relaxed">
                              {phrase.mnemonic.description}
                            </p>

                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-[#f0ede9] text-xs">
                              <div className="flex items-center gap-1.5 text-[#635d59] min-w-0">
                                <span className="material-symbols-outlined text-[15px] text-[#3a492c] shrink-0">
                                  music_note
                                </span>
                                <span className="truncate">{phrase.mnemonic.beatDescription}</span>
                              </div>
                              <button
                                onClick={(e) => handleAudioEcho(phrase, e)}
                                className="inline-flex items-center gap-1 text-[#9f3c16] font-semibold hover:underline self-start sm:self-auto shrink-0"
                                type="button"
                              >
                                <span className="material-symbols-outlined text-sm">replay</span>
                                <span>Re-drill</span>
                              </button>
                            </div>
                          </motion.div>
                        )}

                        {/* Tab 2: Grammar */}
                        {activeTab === 'grammar' && (
                          <motion.div
                            key="tab-grammar"
                            initial={{ opacity: 0, y: 3 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -3 }}
                            transition={{ duration: 0.15 }}
                            className="flex flex-col gap-2.5 px-0.5"
                          >
                            <div className="flex flex-wrap items-center justify-between gap-1.5">
                              <span className="text-xs font-semibold text-[#1c1c19]">
                                {phrase.grammar.title}
                              </span>
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#f4f0ea] text-[#635d59] font-mono font-medium">
                                {phrase.grammar.tag}
                              </span>
                            </div>

                            <p className="text-xs text-[#57524e] leading-relaxed">
                              {phrase.grammar.explanation}
                            </p>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-[#f0ede9]">
                              <div className="flex items-center justify-between sm:flex-col sm:items-start gap-1 p-2 rounded-lg bg-[#fbf9f6] border border-[#f0ede9]">
                                <span className="text-[10px] uppercase tracking-wider text-[#8a726a] font-semibold">
                                  {phrase.grammar.leftCol.label}
                                </span>
                                <span className="text-xs font-mono text-[#1c1c19]">
                                  {phrase.grammar.leftCol.value}
                                </span>
                              </div>
                              <div className="flex items-center justify-between sm:flex-col sm:items-start gap-1 p-2 rounded-lg bg-[#fbf9f6] border border-[#f0ede9]">
                                <span className="text-[10px] uppercase tracking-wider text-[#8a726a] font-semibold">
                                  {phrase.grammar.rightCol.label}
                                </span>
                                <span className="text-xs font-medium text-[#3a492c]">
                                  {phrase.grammar.rightCol.value}
                                </span>
                              </div>
                            </div>
                          </motion.div>
                        )}

                        {/* Tab 3: Phonetics */}
                        {activeTab === 'phonetics' && (
                          <motion.div
                            key="tab-phonetics"
                            initial={{ opacity: 0, y: 3 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -3 }}
                            transition={{ duration: 0.15 }}
                            className="flex flex-col gap-2.5 px-0.5"
                          >
                            <div className="flex flex-wrap items-center justify-between gap-1.5">
                              <span className="text-xs font-semibold text-[#1c1c19]">
                                {phrase.phonetics.title}
                              </span>
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#d6e9c1]/70 text-[#111f07] font-mono font-semibold">
                                {phrase.phonetics.ipa}
                              </span>
                            </div>

                            <p className="text-xs text-[#57524e] leading-relaxed">
                              {phrase.phonetics.analysis}
                            </p>

                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-[#f0ede9] text-xs">
                              <span className="text-[11px] text-[#8a726a]">
                                Friction: <span className="text-[#1c1c19] font-medium">{phrase.phonetics.friction}</span>
                              </span>
                              <button
                                onClick={(e) => handleAudioEcho(phrase, e)}
                                className="inline-flex items-center gap-1 text-[#9f3c16] font-semibold hover:underline self-start sm:self-auto shrink-0"
                                type="button"
                              >
                                <span className="material-symbols-outlined text-sm">slow_motion_video</span>
                                <span>Slow drill</span>
                              </button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  )}
                </AnimatePresence>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. Persistent Docked Mini-Player + SRS Capsule Floating Deck */}
      <div className="fixed bottom-3 inset-x-3 sm:inset-x-6 z-40 max-w-lg md:max-w-xl lg:max-w-2xl mx-auto flex flex-col items-center gap-1.5">
        <SrsDockCapsule
          phraseSpanish={currentPhrase.spanish}
          onRate={(rating) => {
            setPhraseReviewStatus((prev) => ({
              ...prev,
              [currentPhrase.id]: rating === 'easy' ? 'mastered' : 'review',
            }));
          }}
        />
        <MiniPlayer
          currentPhrase={currentPhrase}
          isPlaying={isPlaying}
          onTogglePlay={onTogglePlay}
          onNext={onNextPhrase}
          onPrevious={onPreviousPhrase}
          playbackSpeed={playbackSpeed}
          onToggleSpeed={onToggleSpeed}
          onOpenPlayer={onOpenPlayer}
        />
      </div>
    </div>
  );
};
