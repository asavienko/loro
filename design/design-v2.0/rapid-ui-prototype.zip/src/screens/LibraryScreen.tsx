import React from 'react';
import { JUMP_BACK_IN_ITEMS, SAMPLE_PHRASES } from '../data/mockData';
import { Phrase } from '../types';
import { speakSpanishPhrase } from '../utils/audioEngine';

interface LibraryScreenProps {
  onOpenPack: (packId: string) => void;
  onPlayPhrase: (phrase: Phrase) => void;
}

export const LibraryScreen: React.FC<LibraryScreenProps> = ({
  onOpenPack,
  onPlayPhrase,
}) => {
  return (
    <div className="flex flex-col w-full px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto space-y-6 pt-2 pb-36 select-none">
      <div className="flex flex-col space-y-1 pt-2">
        <h1 className="font-serif text-2xl md:text-3xl font-bold text-[#1c1c19]">
          Earworm Codex &amp; Library
        </h1>
        <p className="text-xs sm:text-sm text-[#635d59]">
          Your acoustic memory vault, cached offline packs, and mastered prosodic cadences.
        </p>
      </div>

      {/* Storage & Codex Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-3.5 bg-[#ffffff] rounded-2xl border border-[#dec0b7]/40 shadow-2xs flex flex-col justify-between">
          <span className="text-[10px] uppercase font-bold tracking-wider text-[#635d59]">
            Mastered Earworms
          </span>
          <p className="font-serif text-2xl font-bold text-[#3a492c] mt-1">
            38 Phrases
          </p>
          <span className="text-[11px] text-[#57423b] mt-0.5">
            100% Spontaneous recall
          </span>
        </div>

        <div className="p-3.5 bg-[#ffffff] rounded-2xl border border-[#dec0b7]/40 shadow-2xs flex flex-col justify-between">
          <span className="text-[10px] uppercase font-bold tracking-wider text-[#635d59]">
            Cached Offline
          </span>
          <p className="font-serif text-2xl font-bold text-[#9f3c16] mt-1">
            18.4 MB
          </p>
          <span className="text-[11px] text-[#57423b] mt-0.5">
            Lossless audio stamps
          </span>
        </div>

        <div className="p-3.5 bg-[#ffffff] rounded-2xl border border-[#dec0b7]/40 shadow-2xs flex flex-col justify-between">
          <span className="text-[10px] uppercase font-bold tracking-wider text-[#635d59]">
            Dialect Regions
          </span>
          <p className="font-serif text-2xl font-bold text-[#1c1c19] mt-1">
            4 Zones
          </p>
          <span className="text-[11px] text-[#57423b] mt-0.5">
            Madrid &amp; Andalucía active
          </span>
        </div>

        <div className="p-3.5 bg-[#ffffff] rounded-2xl border border-[#dec0b7]/40 shadow-2xs flex flex-col justify-between">
          <span className="text-[10px] uppercase font-bold tracking-wider text-[#635d59]">
            Total Audio Reps
          </span>
          <p className="font-serif text-2xl font-bold text-[#7f2500] mt-1">
            1,480 Beats
          </p>
          <span className="text-[11px] text-[#57423b] mt-0.5">
            Circadian cadence synced
          </span>
        </div>
      </div>

      {/* Saved Cadence Packs */}
      <div className="flex flex-col space-y-2.5">
        <h2 className="font-serif text-lg md:text-xl font-bold text-[#1c1c19]">
          Active Study Packs
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {JUMP_BACK_IN_ITEMS.map((pack) => (
            <div
              key={pack.id}
              onClick={() => onOpenPack(pack.packId)}
              className="flex items-center bg-[#ffffff] hover:bg-[#f6f3ee] border border-[#dec0b7]/40 rounded-2xl p-2.5 shadow-2xs cursor-pointer group transition-all"
            >
              <div className="w-14 h-14 rounded-xl overflow-hidden bg-[#f0ede9] shrink-0 mr-3">
                <img
                  src={pack.img}
                  alt={pack.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-serif text-sm font-bold text-[#1c1c19] truncate group-hover:text-[#9f3c16]">
                  {pack.title}
                </h4>
                <p className="text-xs text-[#635d59]">{pack.sub}</p>
                <div className="flex items-center gap-1 mt-1 text-[10px] text-[#3a492c] font-semibold">
                  <span className="material-symbols-outlined text-[13px] material-symbols-fill">
                    check_circle
                  </span>
                  <span>Synced in Spaced Engine</span>
                </div>
              </div>
              <button
                aria-label="Open"
                className="w-8 h-8 rounded-full flex items-center justify-center text-[#635d59] group-hover:text-[#9f3c16]"
                type="button"
              >
                <span className="material-symbols-outlined text-xl">chevron_right</span>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Mastered Phrases List */}
      <div className="flex flex-col space-y-2.5">
        <h2 className="font-serif text-lg md:text-xl font-bold text-[#1c1c19]">
          Mastered Cadence Hall of Fame
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
          {SAMPLE_PHRASES.slice(0, 3).map((phrase) => (
            <div
              key={phrase.id}
              className="p-3 rounded-2xl bg-[#ffffff] border border-[#dec0b7]/30 flex items-center justify-between gap-3 shadow-2xs"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="px-2 py-0.2 rounded-full bg-[#d6e9c1] text-[#111f07] text-[9px] font-bold">
                    100% Retained
                  </span>
                  <span className="text-[10px] text-[#635d59] font-mono">
                    {phrase.meterTag}
                  </span>
                </div>
                <h4 className="font-serif text-sm font-semibold text-[#1c1c19] italic truncate">
                  {phrase.spanish}
                </h4>
                <p className="text-xs text-[#635d59] truncate">"{phrase.english}"</p>
              </div>
              <button
                onClick={() => speakSpanishPhrase(phrase.spanish, 1.0)}
                className="w-9 h-9 rounded-full bg-[#f6f3ee] text-[#9f3c16] flex items-center justify-center hover:bg-[#ffdbcf] active:scale-90 transition-all shrink-0 cursor-pointer"
                type="button"
                title="Pronounce"
              >
                <span className="material-symbols-outlined text-lg">volume_up</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
