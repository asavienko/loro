import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Phrase } from '../types';
import { PREVIOUSLY_PLAYED_PHRASE } from '../data/mockData';
import { playPorcelainTap, speakSpanishPhrase } from '../utils/audioEngine';

interface ListeningQueueScreenProps {
  currentPhrase: Phrase;
  queuePhrases: Phrase[];
  isPlaying: boolean;
  onTogglePlay: () => void;
  onSelectPhrase: (phrase: Phrase) => void;
  onPrevious: () => void;
  onNext: () => void;
  playbackSpeed: number;
  onToggleSpeed: () => void;
  onClose: () => void;
  onReorderQueue: (newQueue: Phrase[]) => void;
}

export const ListeningQueueScreen: React.FC<ListeningQueueScreenProps> = ({
  currentPhrase,
  queuePhrases,
  isPlaying,
  onTogglePlay,
  onSelectPhrase,
  onPrevious,
  onNext,
  playbackSpeed,
  onToggleSpeed,
  onClose,
  onReorderQueue,
}) => {
  const [showPreviouslyPlayed, setShowPreviouslyPlayed] = useState(true);
  const [draggedIdx, setDraggedIdx] = useState<number | null>(null);

  const handleDragStart = (idx: number) => {
    setDraggedIdx(idx);
  };

  const handleDragOver = (e: React.DragEvent, targetIdx: number) => {
    e.preventDefault();
    if (draggedIdx === null || draggedIdx === targetIdx) return;
    const updated = [...queuePhrases];
    const [moved] = updated.splice(draggedIdx, 1);
    updated.splice(targetIdx, 0, moved);
    setDraggedIdx(targetIdx);
    onReorderQueue(updated);
  };

  const handleDragEnd = () => {
    setDraggedIdx(null);
  };

  const handleReplayPrevious = () => {
    playPorcelainTap(1300);
    speakSpanishPhrase(PREVIOUSLY_PLAYED_PHRASE.spanish, playbackSpeed);
  };

  const handleRemoveFromQueue = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    playPorcelainTap(900);
    const updated = queuePhrases.filter((p) => p.id !== id);
    onReorderQueue(updated);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#fcf9f4] flex flex-col justify-between select-none overflow-hidden w-full h-full shadow-2xl">
      {/* 1. Top Navigation Bar with Pull-Down to Dismiss */}
      <motion.div
        drag="y"
        dragConstraints={{ top: 0, bottom: 0 }}
        dragElastic={{ top: 0, bottom: 0.7 }}
        onDragEnd={(_e, info) => {
          if (info.offset.y > 70 || info.velocity.y > 300) {
            playPorcelainTap(900);
            onClose();
          }
        }}
        className="flex flex-col border-b border-[#ebe8e3] bg-[#fcf9f4]/95 backdrop-blur-md z-30 shrink-0 cursor-grab active:cursor-grabbing group w-full"
      >
        {/* Pull Handle */}
        <div className="w-10 h-1.5 rounded-full bg-[#dec0b7] mx-auto mt-2.5 -mb-0.5 opacity-70 group-hover:opacity-100 transition-opacity" />

        <header className="flex items-center justify-between px-4 sm:px-6 md:px-8 pt-1 pb-2.5 max-w-5xl mx-auto w-full">
          <button
            aria-label="Dismiss queue"
            onClick={onClose}
            className="w-9 h-9 -ml-1 rounded-full flex items-center justify-center active:scale-95 transition-transform text-[#1c1c19] hover:bg-[#f6f3ee]"
            type="button"
          >
            <span className="material-symbols-outlined text-2xl">keyboard_arrow_down</span>
          </button>

          <div className="flex flex-col items-center text-center min-w-0 px-2 flex-1">
            <h1 className="font-serif text-base sm:text-lg font-semibold text-[#1c1c19] leading-tight tracking-tight">
              Listening Queue
            </h1>
            <span className="text-[11px] sm:text-xs text-[#57423b] font-medium mt-0.5 truncate max-w-[280px] sm:max-w-md">
              Café &amp; Mañanas (Vol. 03) · {queuePhrases.length + 1} phrases
            </span>
          </div>

          <button
            aria-label="Done"
            onClick={onClose}
            className="whitespace-nowrap px-4 py-1.5 rounded-full bg-[#f0ede9] text-[#7f2500] text-xs font-semibold hover:bg-[#ebe8e3] active:scale-95 transition-all border border-[#dec0b7]/40 shrink-0 shadow-2xs cursor-pointer"
            type="button"
          >
            Done
          </button>
        </header>
      </motion.div>

      {/* 2. Scrollable Queue Body */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 md:px-8 py-4 space-y-5 pb-24 max-w-3xl mx-auto w-full">
        {/* SECTION 1: NOW PLAYING (Streamlined Track Row with Playing State) */}
        <section>
          <div
            id="now-playing-track-row"
            onClick={onTogglePlay}
            className={`rounded-2xl p-2.5 px-3 sm:py-3 sm:px-4 flex items-center justify-between gap-2.5 transition-all duration-200 cursor-pointer shadow-2xs ${
              isPlaying
                ? 'bg-[#fdfaf7] border border-[#9f3c16]/50 ring-1 ring-[#9f3c16]/20'
                : 'bg-[#f6f3ee] hover:bg-[#f0ede9] border border-[#dec0b7]/40'
            }`}
          >
            {/* Left: Track number / Playing equalizer indicator */}
            <div className="w-6 flex items-center justify-center shrink-0">
              {isPlaying ? (
                <div className="flex items-end gap-0.5 h-3.5">
                  <span className="w-0.5 bg-[#9f3c16] rounded-full eq-bar-1" />
                  <span className="w-0.5 bg-[#9f3c16] rounded-full eq-bar-2" />
                  <span className="w-0.5 bg-[#9f3c16] rounded-full eq-bar-3" />
                </div>
              ) : (
                <span className="text-xs sm:text-sm font-bold text-[#635d59]">
                  {currentPhrase.trackNumber}
                </span>
              )}
            </div>

            {/* Middle: Title, Badge, English & Duration (matches queue items) */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="font-serif text-[13.5px] sm:text-sm md:text-[15px] font-semibold text-[#1c1c19] truncate italic">
                  {currentPhrase.spanish}
                </p>

                {currentPhrase.meterTag && (
                  <span className="whitespace-nowrap px-2 py-0.5 text-[9px] sm:text-[10px] font-bold rounded-full shrink-0 bg-[#eae1db] text-[#4b4642] hidden sm:inline-block">
                    {currentPhrase.meterTag}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2 mt-0.5">
                <p className="text-[11px] sm:text-xs text-[#635d59] truncate">
                  "{currentPhrase.english}"
                </p>
                <span className="text-[10px] sm:text-[11px] text-[#57423b] font-mono shrink-0">
                  · {currentPhrase.duration}
                </span>
              </div>
            </div>

            {/* Right: Compact playback controls matching queue buttons */}
            <div
              className="flex items-center gap-1 shrink-0 text-[#635d59]"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                id="queue-prev-phrase-btn"
                aria-label="Previous phrase"
                onClick={onPrevious}
                className="w-7 h-7 sm:w-8 sm:h-8 flex items-center justify-center rounded-full hover:bg-[#ebe8e3] text-[#635d59] hover:text-[#1c1c19] active:scale-90 transition-transform cursor-pointer"
                title="Previous track"
                type="button"
              >
                <span className="material-symbols-outlined text-base sm:text-lg">skip_previous</span>
              </button>

              <button
                id="queue-play-toggle-btn"
                aria-label={isPlaying ? 'Pause' : 'Play'}
                onClick={onTogglePlay}
                className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-[#9f3c16] hover:bg-[#832f0e] text-white flex items-center justify-center shadow-2xs active:scale-95 transition-transform cursor-pointer shrink-0"
                title={isPlaying ? 'Pause' : 'Play'}
                type="button"
              >
                <span className="material-symbols-outlined text-base sm:text-lg material-symbols-fill">
                  {isPlaying ? 'pause' : 'play_arrow'}
                </span>
              </button>

              <button
                id="queue-next-phrase-btn"
                aria-label="Next phrase"
                onClick={onNext}
                className="w-7 h-7 sm:w-8 sm:h-8 flex items-center justify-center rounded-full hover:bg-[#ebe8e3] text-[#635d59] hover:text-[#1c1c19] active:scale-90 transition-transform cursor-pointer"
                title="Next track"
                type="button"
              >
                <span className="material-symbols-outlined text-base sm:text-lg">skip_next</span>
              </button>
            </div>
          </div>
        </section>

        {/* SECTION 2: UP NEXT IN QUEUE */}
        <section className="space-y-2">
          <div className="flex items-center justify-between px-1">
            <span className="text-[10px] sm:text-[11px] tracking-wider uppercase font-bold text-[#635d59]">
              Up Next ({queuePhrases.length} phrases)
            </span>
          </div>

          <div className="space-y-2">
            {queuePhrases.map((phrase, idx) => (
              <div
                key={phrase.id}
                className="relative rounded-2xl overflow-hidden bg-[#e8e4df]"
              >
                {/* Background Under-Card Actions Revealed on Swipe */}
                <div className="absolute inset-0 flex items-center justify-between px-4 text-xs font-bold pointer-events-none select-none">
                  {/* Left swipe background (Play Now) */}
                  <div className="flex items-center gap-1 text-[#3a492c]">
                    <span className="material-symbols-outlined text-lg material-symbols-fill">play_circle</span>
                    <span>Play Now</span>
                  </div>

                  {/* Right swipe background (Remove) */}
                  <div className="flex items-center gap-1 text-[#9f3c16]">
                    <span>Remove</span>
                    <span className="material-symbols-outlined text-lg">delete</span>
                  </div>
                </div>

                {/* Foreground Draggable Card */}
                <motion.div
                  drag="x"
                  dragConstraints={{ left: 0, right: 0 }}
                  dragElastic={0.4}
                  dragSnapToOrigin
                  onDragEnd={(_e, info) => {
                    handleDragEnd();
                    if (info.offset.x > 50 || info.velocity.x > 200) {
                      playPorcelainTap(1400);
                      onSelectPhrase(phrase);
                    } else if (info.offset.x < -50 || info.velocity.x < -200) {
                      playPorcelainTap(900);
                      const updated = queuePhrases.filter((p) => p.id !== phrase.id);
                      onReorderQueue(updated);
                    }
                  }}
                  draggable
                  onDragStart={() => handleDragStart(idx)}
                  onDragOver={(e) => handleDragOver(e as unknown as React.DragEvent, idx)}
                  onClick={() => onSelectPhrase(phrase)}
                  className="relative z-10 bg-[#f6f3ee] hover:bg-[#f0ede9] border border-[#dec0b7]/30 rounded-2xl p-2.5 px-3 sm:py-3 sm:px-4 flex items-center justify-between gap-2.5 active:bg-[#ebe8e3] transition-colors shadow-2xs group cursor-grab active:cursor-grabbing"
                >
                  <div className="w-6 text-center text-xs sm:text-sm font-bold text-[#635d59] shrink-0">
                    {phrase.trackNumber}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-serif text-[13.5px] sm:text-sm md:text-[15px] font-semibold text-[#1c1c19] truncate italic group-hover:text-[#9f3c16] transition-colors">
                        {phrase.spanish}
                      </p>
                      <span
                        className={`whitespace-nowrap px-2 py-0.5 text-[9px] sm:text-[10px] font-bold rounded-full shrink-0 ${
                          phrase.alertTag?.type === 'mastered'
                            ? 'bg-[#d6e9c1]/70 text-[#111f07]'
                            : phrase.alertTag?.type === 'urgent'
                            ? 'bg-[#ffdbcf] text-[#822701]'
                            : phrase.alertTag?.type === 'dietary'
                            ? 'bg-[#e5e2dd] text-[#635d59]'
                            : 'bg-[#eae1db] text-[#4b4642]'
                        }`}
                      >
                        {phrase.alertTag?.label || phrase.meterTag}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <p className="text-[11px] sm:text-xs text-[#635d59] truncate">
                        "{phrase.english}"
                      </p>
                      <span className="text-[10px] sm:text-[11px] text-[#57423b] font-mono shrink-0">
                        · {phrase.duration}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0 text-[#635d59]/70 group-hover:text-[#635d59]">
                    <button
                      aria-label="Audio preview"
                      onClick={(e) => {
                        e.stopPropagation();
                        speakSpanishPhrase(phrase.spanish, playbackSpeed);
                      }}
                      className="w-7 h-7 sm:w-8 sm:h-8 flex items-center justify-center rounded-full hover:bg-[#f0ede9] cursor-pointer"
                      title="Audio preview"
                      type="button"
                    >
                      <span className="material-symbols-outlined text-base sm:text-lg">volume_up</span>
                    </button>

                    <button
                      aria-label="Remove from queue"
                      onClick={(e) => handleRemoveFromQueue(phrase.id, e)}
                      className="w-7 h-7 sm:w-8 sm:h-8 flex items-center justify-center rounded-full hover:bg-[#ffdad6] text-[#8a726a] hover:text-[#ba1a1a] transition-colors cursor-pointer"
                      title="Remove from queue"
                      type="button"
                    >
                      <span className="material-symbols-outlined text-base sm:text-lg">close</span>
                    </button>

                    <div
                      className="cursor-grab active:cursor-grabbing w-7 h-7 sm:w-8 sm:h-8 flex items-center justify-center rounded"
                      title="Drag to reorder"
                    >
                      <span className="material-symbols-outlined text-lg sm:text-xl text-[#8a726a]">
                        drag_handle
                      </span>
                    </div>
                  </div>
                </motion.div>
              </div>
            ))}
          </div>
        </section>

        {/* SECTION 3: PREVIOUSLY PLAYED */}
        <section className="space-y-1.5 pt-1">
          <div className="flex items-center justify-between px-1">
            <span className="text-[10px] sm:text-[11px] tracking-wider uppercase font-bold text-[#635d59]">
              Previously Played (1)
            </span>
            <button
              onClick={() => setShowPreviouslyPlayed(!showPreviouslyPlayed)}
              className="text-[10px] sm:text-[11px] font-semibold text-[#9f3c16] hover:underline cursor-pointer"
              type="button"
            >
              {showPreviouslyPlayed ? 'Hide' : 'Show'}
            </button>
          </div>

          {showPreviouslyPlayed && (
            <div
              onClick={handleReplayPrevious}
              className="bg-[#f6f3ee]/80 border border-[#dec0b7]/40 rounded-2xl p-2.5 px-3 flex items-center gap-3 transition-all hover:bg-[#f0ede9] cursor-pointer group shadow-2xs"
            >
              <div className="w-8 h-8 rounded-xl bg-[#d6e9c1]/60 text-[#3a492c] flex items-center justify-center shrink-0 border border-[#3a492c]/20">
                <span className="material-symbols-outlined text-base">check_circle</span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 leading-none mb-0.5">
                  <span className="text-[10px] font-bold text-[#3a492c] uppercase tracking-wider">
                    {PREVIOUSLY_PLAYED_PHRASE.status}
                  </span>
                  <span className="text-[10px] text-[#635d59]">· {PREVIOUSLY_PLAYED_PHRASE.timeAgo}</span>
                </div>
                <p className="font-serif text-[13px] sm:text-sm text-[#1c1c19] truncate italic font-medium group-hover:text-[#9f3c16] leading-snug">
                  {PREVIOUSLY_PLAYED_PHRASE.spanish}
                </p>
                <p className="text-[11px] sm:text-xs text-[#635d59] truncate">
                  "{PREVIOUSLY_PLAYED_PHRASE.english}"
                </p>
              </div>
              <button
                aria-label="Replay phrase"
                onClick={(e) => {
                  e.stopPropagation();
                  handleReplayPrevious();
                }}
                className="w-8 h-8 rounded-full flex items-center justify-center text-[#635d59] hover:text-[#9f3c16] hover:bg-[#ebe8e3] active:scale-95 transition-transform shrink-0 cursor-pointer"
                type="button"
              >
                <span className="material-symbols-outlined text-lg">replay</span>
              </button>
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
