import React, { useState } from 'react';
import { CadencePack, Phrase } from '../types';
import { playPorcelainTap } from '../utils/audioEngine';

interface ExploreScreenProps {
  onOpenPack: (packId: string) => void;
  onPlayPhrase: (phrase: Phrase) => void;
}

export const ExploreScreen: React.FC<ExploreScreenProps> = ({
  onOpenPack,
  onPlayPhrase,
}) => {
  const [activeMeterFilter, setActiveMeterFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const meterPills = ['All', 'Trochaic (Café)', 'Iambic (Street)', 'Dactylic (Tapas)', 'Flamenco Rumba'];

  const dialectHistory = [
    {
      id: 'dialect-madrid',
      region: 'Madrid Central • Chamberí & Malasaña',
      desc: 'Rapid liaisons, trochaic cafe imperatives, and Madrid lisp /θ/ phonetics.',
      bpm: '118-124 BPM',
      packs: [
        {
          id: 'pack-cafe-mananas',
          title: 'Café & Mañanas (Vol. 03)',
          sub: '16 earworms · Sara Martín & Clara',
          cached: true,
          img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuARSyqQjTe5OmRftOyRB6H9s9wCyY5mCYRtT88IO34sB7wGNZV843oE2LUC-Ex7kYotb12IZBze34zwIT2C06XpwvX7UZniovVCMqL9JaI-bgg5YxIVvLEzaVGHDec0yUh5fEaH7Cnb_iqDBRQANjWsgC2ZyyaFmbgDNNj9IKk1SRYua-Usd12teGsvq4_cZQ4vOK5_3udfWubTQSTkK1yGQSdzIcQa4Ax11KMzQZK3n-s_ay_KpnAfPg',
        },
        {
          id: 'pack-tapas',
          title: 'Tapas & Tabernas (Vol. 01)',
          sub: '21 earworms · Madrid Tapeo',
          cached: false,
          img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDvuB7CJxb83WZXA9hzal1SDMaT0lVF-VgUZss3cSGGMJ1wKT6x9x-oCGEqNVp2-ZtNcLRHVWfE4PR1HNL8tdS2yuaurtgwKvfO-IaoPOfJq-uxmFzCkUGL2SemcqyIlsGZGwxn073061X-lm81VbPQfpytB6DKeER-0VXGlYDPEo96L8KJ_aoWeFJAEKy_bZlDP1jWQRa4kArt6--UcXGyJ7sCl-i0QJvt8AgwKpbgKtvlIxsn0F_hLQ',
        },
      ],
    },
    {
      id: 'dialect-andalucia',
      region: 'Andalucía • Sevilla & Triana',
      desc: 'Syllable aspiration, rhythmic syncopated cadence, musical warm contours.',
      bpm: '104-112 BPM',
      packs: [
        {
          id: 'pack-flamenco',
          title: 'Mercado Verbs in Palapas',
          sub: '14 earworms · Palmas Rhythm',
          cached: false,
          img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAmpCzOu7fGndl_WpvlbofDNhLJ4BiwqvrhxgY3ZciwwNqQfOfuWuLsJPWDW_lfQyC02jsqlDyghaLprvwv6wMRxNNORkMmexMQMr9EEI0bsa7s2cMZt41Afoyc2Qril0GFF_iaHOCyE-qGkMT39SPoDFaFNcLVBdDiP2ZUQAesaqYrsO1eEOgEMcAm0b8nRyV5KqWuAwD5npJuer3agcT0zC9eg-HWmcs_Nbux4HW2tP0APTJ31GCL3g',
        },
        {
          id: 'pack-sobremesa',
          title: 'Sobremesa & Courtyard Drills',
          sub: '18 earworms · Acoustic Warmth',
          cached: false,
          img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCJEUz0Ds-_ZN3zFFyYjNstFcIpO2C10KV5oHP8NVYIBIRdiGvO-qsBDKCpF9uQj1ND93CymxfmEhFRMTYnn0S7nGJo0ARbhZhk6FjUDpZtmKIyem3L8ZuSPAgW3pirSEnqR4OJ5mPPefthkw-SGBxkg3_Bh4jm3ZUllpxI7Ia7wn8p8OdkIn6AfUYJzqGyxsSmgoVfFnt83G7LzVJQ_xtFy8ZhOZ5qQAExINoI0tSkYHjfiphhFXEYUg',
        },
      ],
    },
  ];

  return (
    <div className="flex flex-col w-full px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto space-y-6 pt-2 pb-36 select-none">
      {/* Search Header */}
      <div className="flex flex-col space-y-2 pt-2">
        <h1 className="font-serif text-2xl md:text-3xl font-bold text-[#1c1c19]">
          Cadence Dialect Map
        </h1>
        <p className="text-xs sm:text-sm text-[#635d59]">
          Explore prospective earworm tracks categorized by metric prosody and Iberian speech habits.
        </p>

        {/* Search Field */}
        <div className="relative mt-2">
          <span className="material-symbols-outlined absolute left-3.5 top-3 text-[#8a726a] text-xl">
            search
          </span>
          <input
            type="text"
            placeholder="Search by rhythm, meter, or phrase..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#f6f3ee] border border-[#dec0b7]/50 rounded-2xl pl-11 pr-4 py-2.5 text-xs sm:text-sm text-[#1c1c19] placeholder:text-[#8a726a] focus:outline-none focus:ring-1 focus:ring-[#9f3c16]"
          />
        </div>
      </div>

      {/* Meter Filter Pills */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none -mx-4 px-4 sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
        {meterPills.map((pill) => (
          <button
            key={pill}
            onClick={() => {
              playPorcelainTap(1500);
              setActiveMeterFilter(pill);
            }}
            className={`whitespace-nowrap px-3.5 py-1.5 rounded-full text-xs font-semibold active:scale-95 transition-all border shrink-0 ${
              activeMeterFilter === pill
                ? 'bg-[#9f3c16] text-white border-[#9f3c16] shadow-2xs'
                : 'bg-[#f0ede9] text-[#635d59] border-[#dec0b7]/30 hover:bg-[#ebe8e3]'
            }`}
            type="button"
          >
            {pill}
          </button>
        ))}
      </div>

      {/* Dialect History */}
      <div className="space-y-6">
        {dialectHistory.map((shelf) => (
          <div key={shelf.id} className="flex flex-col space-y-3">
            <div className="flex items-center justify-between border-b border-[#dec0b7]/30 pb-2">
              <div>
                <h3 className="font-serif text-base sm:text-lg font-bold text-[#1c1c19]">
                  {shelf.region}
                </h3>
                <p className="text-[11px] sm:text-xs text-[#635d59]">{shelf.desc}</p>
              </div>
              <span className="text-[11px] sm:text-xs font-mono text-[#9f3c16] font-semibold">
                {shelf.bpm}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3.5">
              {shelf.packs.map((packItem) => (
                <button
                  key={packItem.id}
                  onClick={() => onOpenPack(packItem.id)}
                  className="flex flex-col bg-[#ffffff] hover:bg-[#f6f3ee] border border-[#dec0b7]/40 rounded-2xl p-2.5 shadow-2xs text-left active:scale-[0.98] transition-all group cursor-pointer"
                  type="button"
                >
                  <div className="relative w-full aspect-square rounded-xl overflow-hidden bg-[#f0ede9] mb-2">
                    <img
                      src={packItem.img}
                      alt={packItem.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      referrerPolicy="no-referrer"
                    />
                    {packItem.cached && (
                      <span className="absolute top-1.5 right-1.5 bg-[#d6e9c1] text-[#111f07] text-[9px] font-bold px-1.5 py-0.5 rounded-full flex items-center gap-0.5 shadow-2xs">
                        <span className="material-symbols-outlined text-[11px] material-symbols-fill">
                          check_circle
                        </span>
                        <span>Cached</span>
                      </span>
                    )}
                  </div>
                  <h4 className="font-serif text-xs sm:text-sm font-bold text-[#1c1c19] truncate group-hover:text-[#9f3c16] transition-colors">
                    {packItem.title}
                  </h4>
                  <p className="text-[10px] sm:text-xs text-[#635d59] truncate mt-0.5">
                    {packItem.sub}
                  </p>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
