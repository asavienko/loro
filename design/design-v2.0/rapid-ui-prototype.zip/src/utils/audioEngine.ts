// Web Audio & Speech Synthesis Audio Engine for Loro

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    audioCtx = new AudioCtxClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

// Synthesizes an authentic porcelain teaspoon tap sound for metronomic cadence
export function playPorcelainTap(frequency = 1200, decay = 0.08) {
  triggerHaptic('light');
  try {
    const ctx = getAudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(frequency, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(800, ctx.currentTime + decay);

    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + decay);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + decay);
  } catch (err) {
    console.warn('AudioContext error:', err);
  }
}

// Play success chord for Mastered / Easy rating
export function playMasteryChime() {
  triggerHaptic('success');
  try {
    const ctx = getAudioContext();
    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const startTime = ctx.currentTime + idx * 0.06;
      const duration = 0.4;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, startTime);

      gain.gain.setValueAtTime(0.18, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + duration);
    });
  } catch (err) {
    console.warn('AudioContext error:', err);
  }
}

// Play punchy terracotta double recoil sound for Hard rating
export function playHardRecoil() {
  triggerHaptic('double');
  try {
    const ctx = getAudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const decay = 0.15;

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(240, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(90, ctx.currentTime + decay);

    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + decay);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + decay);
  } catch (err) {
    console.warn('AudioContext error:', err);
  }
}

// Vibration API integration for rich tactile haptic feedback
export type HapticFeedbackType =
  | 'light'
  | 'medium'
  | 'heavy'
  | 'selection'
  | 'success'
  | 'double'
  | 'phase'
  | 'tick';

export function triggerHaptic(
  type: HapticFeedbackType = 'light',
  customPattern?: number | number[]
) {
  if (typeof window === 'undefined' || !('navigator' in window) || !('vibrate' in navigator)) {
    return;
  }

  try {
    if (customPattern !== undefined) {
      navigator.vibrate(customPattern);
      return;
    }

    switch (type) {
      case 'light':
      case 'tick':
        navigator.vibrate(12); // subtle tactile click
        break;
      case 'selection':
        navigator.vibrate(18); // crisp notch feel
        break;
      case 'medium':
        navigator.vibrate(30); // firm tap for play/skip
        break;
      case 'heavy':
        navigator.vibrate(50); // solid resonant strike
        break;
      case 'phase':
        // Distinct cadence double-pulse for switching learning phases (Mnemonic -> Phonetics -> Grammar)
        navigator.vibrate([16, 45, 22]);
        break;
      case 'success':
        // Upbeat rhythm for mastery
        navigator.vibrate([15, 30, 25, 30, 40]);
        break;
      case 'double':
        // Recoil sensation for challenging review
        navigator.vibrate([25, 40, 35]);
        break;
      default:
        navigator.vibrate(15);
    }
  } catch {
    // Gracefully ignore environments where vibration permissions are restricted
  }
}

// Speech synthesis for authentic Castilian Spanish phrase drill
export function speakSpanishPhrase(
  phraseText: string,
  rate = 1.0,
  onEnd?: () => void
) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    if (onEnd) setTimeout(onEnd, 1500);
    return;
  }

  window.speechSynthesis.cancel();

  // Strip guillemets
  const cleanText = phraseText.replace(/[«»]/g, '').trim();
  const utterance = new SpeechSynthesisUtterance(cleanText);

  utterance.lang = 'es-ES';
  utterance.rate = Math.max(0.6, Math.min(1.5, rate));
  utterance.pitch = 1.0;

  // Try to find a European Spanish voice
  const voices = window.speechSynthesis.getVoices();
  const esVoice =
    voices.find((v) => v.lang === 'es-ES') ||
    voices.find((v) => v.lang.startsWith('es')) ||
    null;

  if (esVoice) {
    utterance.voice = esVoice;
  }

  if (onEnd) {
    utterance.onend = () => onEnd();
    utterance.onerror = () => onEnd();
  }

  window.speechSynthesis.speak(utterance);
}

export function stopSpeaking() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}
