export interface Phrase {
  id: string;
  trackNumber: string;
  spanish: string;
  english: string;
  phonetic: string;
  ipa?: string;
  meterTag: string; // "Trochaic • 8 Syll", "Iambic", etc.
  categoryTag: string; // "Café & Tapas", "Dietary Inquiry", etc.
  retentionPercent: number;
  retentionStatus: string; // "94% Automaticity", "Due in 10m", "Mastered", etc.
  rank?: string; // "Rank V", "Permanent Earworm"
  duration: string; // "0:38", "1:12"
  durationSeconds: number;
  alertTag?: {
    type: 'mastered' | 'urgent' | 'dietary' | 'normal';
    label: string;
  };
  mnemonic: {
    title: string;
    tag: string;
    icon: string;
    description: string;
    beatDescription: string;
    recallPercent?: string;
  };
  grammar: {
    title: string;
    tag: string;
    explanation: string;
    leftCol: { label: string; value: string };
    rightCol: { label: string; value: string };
  };
  phonetics: {
    title: string;
    ipa: string;
    analysis: string;
    friction: string;
  };
  coverImage?: string;
}

export interface CadencePack {
  id: string;
  vol: string;
  title: string;
  subtitle: string;
  speakers: string;
  phrasesCount: number;
  runDuration: string;
  scholarsCount: string;
  cachedSize: string;
  cached: boolean;
  coverImage: string;
  bpm: number;
  dialect: string;
  phrases: Phrase[];
}

export interface CircadianWave {
  id: string;
  waveNumber: string;
  time: string;
  title: string;
  description: string;
  dueStatus: string;
  isDue: boolean;
  bpm: number;
  phraseCount: number;
  durationMins: number;
  state: 'due' | 'locked' | 'evening';
  unlocksIn?: string;
  wavePattern: number[]; // heights 1-10
}

export type ScreenType = 'rhythm' | 'pack-detail' | 'now-playing' | 'queue' | 'explore' | 'library';
