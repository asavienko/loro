import { CadencePack, CircadianWave, Phrase } from '../types';

export const CURRENT_USER = {
  name: 'Clara',
  greeting: '¡Buenos días, Clara!',
  avatar:
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80',
  streak: 38,
  repsSpaced: '38 Reps Spaced',
  retentionPercent: '94% Retention',
  nextDue: 'Now',
  dialect: 'Castilian',
};

export const SAMPLE_PHRASES: Phrase[] = [
  {
    id: 'phrase-1',
    trackNumber: '01',
    spanish: '«Me pone un cortado, por favor»',
    english: 'A cortado for me, please',
    phonetic: '[meh POH-neh oon kor-TAH-doh, por fah-VOR]',
    ipa: '[me ˈpo.ne uŋ koɾˈta.ðo]',
    meterTag: 'Trochaic • 8 Syll',
    categoryTag: 'Café & Tapas',
    retentionPercent: 94,
    retentionStatus: '94% Automaticity',
    rank: 'Rank V',
    duration: '0:38',
    durationSeconds: 38,
    alertTag: {
      type: 'normal',
      label: 'PLAYING',
    },
    mnemonic: {
      title: 'Cortado Porcelain Tap',
      tag: '4-Beat Pulse',
      icon: 'coffee',
      description:
        'Imagine tapping a porcelain espresso cup with your teaspoon: un-DOS-tres-cuatro. The rhythmic surge lands straight on «PO-ne» and «cor-TA-do».',
      beatDescription: 'Trochaic beat: DA-da da-DA-da',
      recallPercent: '96% Recall',
    },
    grammar: {
      title: '«Me pone...» Courtesy Formula',
      tag: '3rd Pers. Present Indicative',
      explanation:
        'Unlike the stiff imperative «Póngame» or English "Give me", native Spanish speakers in cafes employ the 3rd person singular present indicative: "¿Usted me pone...?" with the subject omitted. It translates literally as "Does your honor put/serve me...", radiating warm colloquial politeness.',
      leftCol: { label: 'Pronoun Syntax', value: 'Me [indirect] + pone [verb]' },
      rightCol: { label: 'Formality Level', value: 'Warm Café Social Polite' },
    },
    phonetics: {
      title: 'Alveolar Tap /ɾ/ & Syllable Blending',
      ipa: 'IPA: [me ˈpo.ne uŋ koɾˈta.ðo]',
      analysis:
        'Notice the liaison in «pone un»: the vowel [e] links seamlessly into [u] without glottal hesitation: /po-newn/. Soft dental fricative on -do [ðo].',
      friction: 'Low (Trochaic Flow)',
    },
    coverImage:
      'https://lh3.googleusercontent.com/aida-public/AB6AXuARSyqQjTe5OmRftOyRB6H9s9wCyY5mCYRtT88IO34sB7wGNZV843oE2LUC-Ex7kYotb12IZBze34zwIT2C06XpwvX7UZniovVCMqL9JaI-bgg5YxIVvLEzaVGHDec0yUh5fEaH7Cnb_iqDBRQANjWsgC2ZyyaFmbgDNNj9IKk1SRYua-Usd12teGsvq4_cZQ4vOK5_3udfWubTQSTkK1yGQSdzIcQa4Ax11KMzQZK3n-s_ay_KpnAfPg',
  },
  {
    id: 'phrase-2',
    trackNumber: '02',
    spanish: '«¿Tienen leche de avena?»',
    english: 'Do you have oat milk?',
    phonetic: '[TYEH-nehn LEH-cheh deh ah-VEH-nah]',
    ipa: '[ˈtje.nen ˈle.tʃe ðe aˈβe.na]',
    meterTag: 'Iambic cadence',
    categoryTag: 'Dietary Inquiry',
    retentionPercent: 60,
    retentionStatus: '60% Retention',
    rank: 'Due tomorrow',
    duration: '1:12',
    durationSeconds: 72,
    alertTag: {
      type: 'normal',
      label: 'Iambic',
    },
    mnemonic: {
      title: 'The Oat Wave Rhythm',
      tag: 'Rising Intonation',
      icon: 'grain',
      description:
        'Think of «a-VE-na» as an ocean wave reaching its crest right at the VE syllable, then gently subsiding at the bar counter.',
      beatDescription: 'Soft question contour: rise at midpoint',
      recallPercent: '72% Recall',
    },
    grammar: {
      title: 'Plural «Tienen» vs «Hay»',
      tag: '3rd Plural Present',
      explanation:
        'Addressing the establishment as a plural entity (ustedes) is the most natural, welcoming way to ask stock availability in Spain and Latin America without sounding overly direct.',
      leftCol: { label: 'Subject', value: 'Ustedes (Implied)' },
      rightCol: { label: 'Preposition', value: 'de [origin/type]' },
    },
    phonetics: {
      title: 'Bilabial Approximant [β̞] in «avena»',
      ipa: 'IPA: [ˈtje.nen ˈle.tʃe ðe aˈβe.na]',
      analysis:
        'Spanish «v» in avena sounds identical to a soft «b» between vowels: lips do not touch completely, producing smooth airflow without English teeth friction.',
      friction: 'Minimal',
    },
    coverImage:
      'https://lh3.googleusercontent.com/aida-public/AB6AXuBGTSyTGmTmiBNymbmXye2CZY1RHK-rO6YYB-nYa8jNsN1WuXqx3nYQMiU-U913xQkHc03xn9dKxE69YXA8epbdIb5DFZXeg5SkzJIfR6NuMaA2JfaCpvChcLSDRQ88IpmrZgY0mpw0tlmow-DzHIop1IvO--fR_GcftXFga45j_txga2SD55dRqRIwqy8wXUJpfObM0izOvSdOpS7C4tRumMWeSEl_W6v703E513Mf-Sl01-A_tLySig',
  },
  {
    id: 'phrase-3',
    trackNumber: '03',
    spanish: '«La cuenta, por favor»',
    english: 'The check, please',
    phonetic: '[lah KWEHN-tah, por fah-VOR]',
    ipa: '[la ˈkwen̪.ta poɾ faˈβoɾ]',
    meterTag: 'Mastered',
    categoryTag: 'Checkout',
    retentionPercent: 100,
    retentionStatus: '100% Spontaneous',
    rank: 'Permanent Earworm',
    duration: '0:54',
    durationSeconds: 54,
    alertTag: {
      type: 'mastered',
      label: 'Mastered',
    },
    mnemonic: {
      title: 'Air Pen Scribble Gesture',
      tag: 'Physical Anchor',
      icon: 'receipt_long',
      description:
        'Catch the waiter\'s eye across the terrace, subtly trace an invisible signature in the air while uttering: «La CUEN-ta».',
      beatDescription: 'Automatic reflex achieved',
      recallPercent: '99% Recall',
    },
    grammar: {
      title: 'Definite Article in Request',
      tag: 'Feminine Singular',
      explanation:
        'Always use the definite article «la» (never indefinite «una cuenta») because the bill for this table is specific and unique.',
      leftCol: { label: 'Root', value: 'Contar (to count)' },
      rightCol: { label: 'Etiquette', value: 'Polite Minimalist' },
    },
    phonetics: {
      title: 'Diphthong /we/ in «cuenta»',
      ipa: 'IPA: [la ˈkwen̪.ta poɾ faˈβoɾ]',
      analysis:
        'The «cue-» produces an explosive glide /kw/. Stress falls punchily on [KWEHN], releasing softly onto [tah].',
      friction: 'Acoustic Cadence: Punchy Spondee',
    },
    coverImage:
      'https://lh3.googleusercontent.com/aida-public/AB6AXuDvuB7CJxb83WZXA9hzal1SDMaT0lVF-VgUZss3cSGGMJ1wKT6x9x-oCGEqNVp2-ZtNcLRHVWfE4PR1HNL8tdS2yuaurtgwKvfO-IaoPOfJq-uxmFzCkUGL2SemcqyIlsGZGwxn073061X-lm81VbPQfpytB6DKeER-0VXGlYDPEo96L8KJ_aoWeFJAEKy_bZlDP1jWQRa4kArt6--UcXGyJ7sCl-i0QJvt8AgwKpbgKtvlIxsn0F_hLQ',
  },
  {
    id: 'phrase-4',
    trackNumber: '04',
    spanish: '«¿Se puede en la terraza?»',
    english: 'Can we sit outside on the terrace?',
    phonetic: '[seh PWEH-deh ehn lah teh-RRAH-thah]',
    ipa: '[se ˈpwe.ðe en la teˈra.θa]',
    meterTag: 'Lateral [A] Focus',
    categoryTag: 'Outdoor Seating',
    retentionPercent: 78,
    retentionStatus: '78% Retention',
    rank: '4 Interval Days',
    duration: '1:08',
    durationSeconds: 68,
    alertTag: {
      type: 'urgent',
      label: 'Due in 10m',
    },
    mnemonic: {
      title: 'Sunlit Terrace Pivot',
      tag: 'Visual Anchor',
      icon: 'deck',
      description:
        'Glance toward the sunny sidewalk umbrellas. The prompt starts with a featherweight whisper: «se puede» ("is it permitted").',
      beatDescription: 'Sunny afternoon drill',
      recallPercent: '84% Recall',
    },
    grammar: {
      title: 'Impersonal «Se» of Permission',
      tag: 'Passive Reflexive',
      explanation:
        '«¿Se puede...?» replaces "Can I / Can we", making inquiries sound polite and unpresumptuous. The main verb sentarse (to sit) is colloquially elided.',
      leftCol: { label: 'Structure', value: 'Se + puede [modal]' },
      rightCol: { label: 'Omission', value: '[sentarse] omitted' },
    },
    phonetics: {
      title: 'Madrid Lisp [θ] & Trill /r/',
      ipa: 'IPA: [se ˈpwe.ðe en la teˈra.θa]',
      analysis:
        'In Castilian Spanish, the «z» in terraza is articulated with the tongue between teeth as [θ] (like "thin"), preceded by a vivid double-r roll.',
      friction: 'Dialect: Castilian Madrid',
    },
    coverImage:
      'https://lh3.googleusercontent.com/aida-public/AB6AXuBG-CRnGKgH15nTbRi7Zka7S2hYW1gJPRq8JDUud5hCp_2reJbaXLHL4sAllF-F-pcMxvsR2tx2FaH1pz_KAQFBrmhgfOWhs6jn7IhFC-bR6jVYYSb1BWYofDhvYS95pqf1NNt8FdgO1vAdwBkqw21f4xYoOoUsyNAPQG4BW12ToW9mC6xJXsP5KgWeE0a_YGrR-lPJUOxAFOoe-me1wZ46w62qGOY9bpXMdD8wqkTBm8HenYoSkaa7OA',
  },
  {
    id: 'phrase-5',
    trackNumber: '05',
    spanish: '«Sin gluten, por favor»',
    english: 'Gluten-free, please',
    phonetic: '[seen GLOO-tehn, por fah-VOR]',
    ipa: '[sin ˈɡlu.ten poɾ faˈβoɾ]',
    meterTag: 'Accent Accentuation',
    categoryTag: 'Dietary Alert',
    retentionPercent: 45,
    retentionStatus: '45% Needs Review',
    rank: 'Queue soon',
    duration: '0:48',
    durationSeconds: 48,
    alertTag: {
      type: 'dietary',
      label: 'Dietary',
    },
    mnemonic: {
      title: 'Clear Stop Cue',
      tag: 'Alert Tone',
      icon: 'no_meals',
      description:
        'Emphasize the crisp, sharp «Sin» to clearly signal dietary necessity to the barista before the milk is poured.',
      beatDescription: 'Scheduled in spaced deck',
      recallPercent: '58% Recall',
    },
    grammar: {
      title: 'Prepositional Modifier «Sin»',
      tag: 'Preposition + Noun',
      explanation:
        'In Spanish gastronomy, «sin» modifies beverages and dishes without requiring the article (e.g. «sin azúcar», «sin lactosa», «sin gluten»).',
      leftCol: { label: 'Modifier', value: 'Sin + [allergen]' },
      rightCol: { label: 'Frequency', value: 'Critical Daily Use' },
    },
    phonetics: {
      title: 'Penultimate Stress on «GLU-ten»',
      ipa: 'IPA: [sin ˈɡlu.ten poɾ faˈβoɾ]',
      analysis:
        'Spanish stresses the first syllable «GLU-ten» with a pure Spanish /u/ vowel, contrasting with English elongation /ɡluːtən/.',
      friction: 'Acoustic Precision: High',
    },
    coverImage:
      'https://lh3.googleusercontent.com/aida-public/AB6AXuAmpCzOu7fGndl_WpvlbofDNhLJ4BiwqvrhxgY3ZciwwNqQfOfuWuLsJPWDW_lfQyC02jsqlDyghaLprvwv6wMRxNNORkMmexMQMr9EEI0bsa7s2cMZt41Afoyc2Qril0GFF_iaHOCyE-qGkMT39SPoDFaFNcLVBdDiP2ZUQAesaqYrsO1eEOgEMcAm0b8nRyV5KqWuAwD5npJuer3agcT0zC9eg-HWmcs_Nbux4HW2tP0APTJ31GCL3g',
  },
  {
    id: 'phrase-6',
    trackNumber: '06',
    spanish: '«Una caña bien tirada, jefe»',
    english: 'A properly poured draft beer, boss',
    phonetic: '[OO-nah KAH-nyah byehn tee-RAH-dah, HEH-feh]',
    ipa: '[ˈu.na ˈka.ɲa ˈbjen tiˈɾa.ða ˈxe.fe]',
    meterTag: 'Madrid slang',
    categoryTag: 'Tapas Bar',
    retentionPercent: 52,
    retentionStatus: '52% Retention',
    rank: '3 Days',
    duration: '0:35',
    durationSeconds: 35,
    alertTag: {
      type: 'normal',
      label: 'Madrid slang',
    },
    mnemonic: {
      title: 'Foam Crown Visualizer',
      tag: 'Colloquial Rapport',
      icon: 'sports_bar',
      description:
        'Notice the rhythm on «bien ti-RA-da». A caña in Madrid must have a creamy two-finger foam crown (giste).',
      beatDescription: 'Rhythmic tap on bar mahogany',
      recallPercent: '65% Recall',
    },
    grammar: {
      title: 'Vocative «Jefe» in Bar Madrid',
      tag: 'Informal Honorific',
      explanation:
        'Addressing the bartender as «jefe» (boss) or «compañero» signals seasoned local fluency and immediate warmth without being impudent.',
      leftCol: { label: 'Term', value: 'Jefe (Boss/Friend)' },
      rightCol: { label: 'Context', value: 'Traditional Cervercerías' },
    },
    phonetics: {
      title: 'Palatal Nasal /ɲ/ in «caña»',
      ipa: 'IPA: [ˈka.ɲa]',
      analysis:
        'Arch of the tongue presses smoothly against hard palate for the ñ sound, followed by crisp non-aspirated /k/.',
      friction: 'Madrid Local Flow',
    },
    coverImage:
      'https://lh3.googleusercontent.com/aida-public/AB6AXuBpYjBAsi4EEY5kyiYM-TQhpZHpoerlAmg38carBrnRXzKZhEvUq1oZri29rAxj2tg3Z54cpjqc490e4NjsfC0zSSkG5eHWH_fmLRVCZ1CZlOsYg9NNBNS4oohWMrsIVYXkhwYumfVAjx1DcNya9FErRQa8LdsVgjm7PO-wJihT_p-B2t0IHo2niPjGL_JAx7GIc5oJGscNbm-LwfjAPof770GUAfaL7t3z9uWo34dMr72hcDa8gUMgAQ',
  },
];

export const PREVIOUSLY_PLAYED_PHRASE = {
  id: 'prev-1',
  trackNumber: '00',
  spanish: '«Buenos días, un cortado»',
  english: 'Good morning, a cortado',
  timeAgo: '0:42 ago',
  status: 'Mastered',
};

export const MAIN_CADENCE_PACK: CadencePack = {
  id: 'pack-cafe-mananas',
  vol: 'VOL. 03',
  title: 'Café & Mañanas',
  subtitle: 'Café Culture & Morning Orders',
  speakers: 'Sara Martín & Clara',
  phrasesCount: 16,
  runDuration: '24m run',
  scholarsCount: '14,890 scholars',
  cachedSize: '18.4 MB Cached',
  cached: false,
  bpm: 118,
  dialect: 'Madrid • 1.25x',
  coverImage:
    'https://lh3.googleusercontent.com/aida-public/AB6AXuARSyqQjTe5OmRftOyRB6H9s9wCyY5mCYRtT88IO34sB7wGNZV843oE2LUC-Ex7kYotb12IZBze34zwIT2C06XpwvX7UZniovVCMqL9JaI-bgg5YxIVvLEzaVGHDec0yUh5fEaH7Cnb_iqDBRQANjWsgC2ZyyaFmbgDNNj9IKk1SRYua-Usd12teGsvq4_cZQ4vOK5_3udfWubTQSTkK1yGQSdzIcQa4Ax11KMzQZK3n-s_ay_KpnAfPg',
  phrases: SAMPLE_PHRASES,
};

export const CIRCADIAN_WAVES: CircadianWave[] = [
  {
    id: 'wave-1',
    waveNumber: 'Wave 01',
    time: '08:00',
    title: '08:00 Matinal Coffee Ritual',
    description: 'Castilian cadence warm-up: quick ordering, milk preferences, and polite morning interruptions.',
    dueStatus: 'Due Now',
    isDue: true,
    bpm: 118,
    phraseCount: 6,
    durationMins: 4,
    state: 'due',
    wavePattern: [4, 8, 5, 9, 10, 6, 8, 7, 9, 4, 6, 3, 7, 4],
  },
  {
    id: 'wave-2',
    waveNumber: 'Wave 02',
    time: '13:00',
    title: '13:00 Subsuelo Commute Wave',
    description: 'Madrid Line 10 rapid exchange, fare gate gestures, and high-frequency transit reflexive verbs.',
    dueStatus: 'Unlocks in 3h 40m',
    isDue: false,
    bpm: 126,
    phraseCount: 5,
    durationMins: 3,
    state: 'locked',
    unlocksIn: '3h 40m',
    wavePattern: [4, 5, 7, 4, 8, 5, 3, 6, 5, 7, 3, 4],
  },
  {
    id: 'wave-3',
    waveNumber: 'Wave 03',
    time: '19:00',
    title: '19:00 Sobremesa Deep Retention',
    description: 'Low-tempo subconscious audio imprint drills before evening conversation with native companions.',
    dueStatus: 'Consolidation • 9h 40m',
    isDue: false,
    bpm: 92,
    phraseCount: 3,
    durationMins: 2,
    state: 'evening',
    unlocksIn: '9h 40m',
    wavePattern: [3, 4, 3, 5, 4, 3, 4, 3],
  },
];

export const JUMP_BACK_IN_ITEMS = [
  {
    id: 'jump-1',
    title: 'Café Culture',
    sub: '16 phrases · 100%',
    packId: 'pack-cafe-mananas',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBpYjBAsi4EEY5kyiYM-TQhpZHpoerlAmg38carBrnRXzKZhEvUq1oZri29rAxj2tg3Z54cpjqc490e4NjsfC0zSSkG5eHWH_fmLRVCZ1CZlOsYg9NNBNS4oohWMrsIVYXkhwYumfVAjx1DcNya9FErRQa8LdsVgjm7PO-wJihT_p-B2t0IHo2niPjGL_JAx7GIc5oJGscNbm-LwfjAPof770GUAfaL7t3z9uWo34dMr72hcDa8gUMgAQ',
  },
  {
    id: 'jump-2',
    title: 'Tapas Crawl',
    sub: '21 phrases · 75%',
    packId: 'pack-tapas',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDvuB7CJxb83WZXA9hzal1SDMaT0lVF-VgUZss3cSGGMJ1wKT6x9x-oCGEqNVp2-ZtNcLRHVWfE4PR1HNL8tdS2yuaurtgwKvfO-IaoPOfJq-uxmFzCkUGL2SemcqyIlsGZGwxn073061X-lm81VbPQfpytB6DKeER-0VXGlYDPEo96L8KJ_aoWeFJAEKy_bZlDP1jWQRa4kArt6--UcXGyJ7sCl-i0QJvt8AgwKpbgKtvlIxsn0F_hLQ',
  },
  {
    id: 'jump-3',
    title: 'Metro Drift',
    sub: '18 phrases · Transit',
    packId: 'pack-metro',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBG-CRnGKgH15nTbRi7Zka7S2hYW1gJPRq8JDUud5hCp_2reJbaXLHL4sAllF-F-pcMxvsR2tx2FaH1pz_KAQFBrmhgfOWhs6jn7IhFC-bR6jVYYSb1BWYofDhvYS95pqf1NNt8FdgO1vAdwBkqw21f4xYoOoUsyNAPQG4BW12ToW9mC6xJXsP5KgWeE0a_YGrR-lPJUOxAFOoe-me1wZ46w62qGOY9bpXMdD8wqkTBm8HenYoSkaa7OA',
  },
  {
    id: 'jump-4',
    title: 'Sobremesa',
    sub: '14 phrases · New',
    packId: 'pack-sobremesa',
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCJEUz0Ds-_ZN3zFFyYjNstFcIpO2C10KV5oHP8NVYIBIRdiGvO-qsBDKCpF9uQj1ND93CymxfmEhFRMTYnn0S7nGJo0ARbhZhk6FjUDpZtmKIyem3L8ZuSPAgW3pirSEnqR4OJ5mPPefthkw-SGBxkg3_Bh4jm3ZUllpxI7Ia7wn8p8OdkIn6AfUYJzqGyxsSmgoVfFnt83G7LzVJQ_xtFy8ZhOZ5qQAExINoI0tSkYHjfiphhFXEYUg',
  },
];

export const HEAVY_ROTATION_PACKS = [
  {
    id: 'rot-1',
    title: 'Madrid Corner Talk',
    tag: 'Acoustic Indie',
    bpm: '108 BPM • 18 Cadences',
    progress: 80,
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBGTSyTGmTmiBNymbmXye2CZY1RHK-rO6YYB-nYa8jNsN1WuXqx3nYQMiU-U913xQkHc03xn9dKxE69YXA8epbdIb5DFZXeg5SkzJIfR6NuMaA2JfaCpvChcLSDRQ88IpmrZgY0mpw0tlmow-DzHIop1IvO--fR_GcftXFga45j_txga2SD55dRqRIwqy8wXUJpfObM0izOvSdOpS7C4tRumMWeSEl_W6v703E513Mf-Sl01-A_tLySig',
  },
  {
    id: 'rot-2',
    title: 'Mercado Verbs in Palapas',
    tag: 'Rumba 104 BPM',
    bpm: '104 BPM • 14 Cadences',
    progress: 40,
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAmpCzOu7fGndl_WpvlbofDNhLJ4BiwqvrhxgY3ZciwwNqQfOfuWuLsJPWDW_lfQyC02jsqlDyghaLprvwv6wMRxNNORkMmexMQMr9EEI0bsa7s2cMZt41Afoyc2Qril0GFF_iaHOCyE-qGkMT39SPoDFaFNcLVBdDiP2ZUQAesaqYrsO1eEOgEMcAm0b8nRyV5KqWuAwD5npJuer3agcT0zC9eg-HWmcs_Nbux4HW2tP0APTJ31GCL3g',
  },
  {
    id: 'rot-3',
    title: 'Taxi & Midnight Requests',
    tag: 'Synthwave Loro',
    bpm: '120 BPM • 12 Cadences',
    progress: 25,
    img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCKdYUjPtn0ETbqfnLzmZcAQIojp14guVKct_p6G79C8IGdR4w4qbshtL3pGNaBJgpYHdo0XaDPvBzDyPkd4Gnb36j1XWXLH0dBQxTkjNfgtVtk6Cf8enk7XnyaYI16YzHWZk_0ciaNyjWD60o_JAqGr8l4txyxRtxHqdCxFOo4tW5qUuz6UiCkxSlRO0u-UQVT3xHDpNLJiTvJC3bSFDbpf_ui7Clz2LWUOSC4WwB31_iaSmMuz7TZdg',
  },
];
