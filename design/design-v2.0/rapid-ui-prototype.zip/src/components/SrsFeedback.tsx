import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { playHardRecoil, playMasteryChime, triggerHaptic } from '../utils/audioEngine';

export function triggerSparkleBurst(targetElement: HTMLElement) {
  const rect = targetElement.getBoundingClientRect();
  const originX = rect.left + rect.width / 2;
  const originY = rect.top + rect.height / 2;

  const particleCount = 18;
  const colors = ['#f59e0b', '#d6e9c1', '#bacda6', '#fef08a', '#84cc16', '#ffedd5', '#ffb59c'];
  const icons = ['★', '✦', '•', '◆', '✨', '✓'];

  for (let i = 0; i < particleCount; i++) {
    const p = document.createElement('span');
    p.className = 'sparkle-particle font-mono select-none font-bold text-xs pointer-events-none';
    p.textContent = icons[Math.floor(Math.random() * icons.length)];

    const angle = Math.PI * 2 * (i / particleCount) + (Math.random() * 0.3 - 0.15);
    const distance = 42 + Math.random() * 48;
    const tx = Math.cos(angle) * distance;
    const ty = Math.sin(angle) * distance - 20;
    const rot = Math.random() * 360 - 180 + 'deg';
    const color = colors[Math.floor(Math.random() * colors.length)];

    p.style.setProperty('--tx', `${tx}px`);
    p.style.setProperty('--ty', `${ty}px`);
    p.style.setProperty('--rot', rot);
    p.style.color = color;
    p.style.fontSize = 9 + Math.random() * 8 + 'px';
    p.style.left = `${originX}px`;
    p.style.top = `${originY}px`;
    p.style.position = 'fixed';

    document.body.appendChild(p);

    setTimeout(() => {
      if (p.parentNode) p.parentNode.removeChild(p);
    }, 850);
  }
}

export function triggerEnergyRing(targetElement: HTMLElement) {
  const rect = targetElement.getBoundingClientRect();
  const ring = document.createElement('div');
  ring.className =
    'fixed rounded-full border-2 border-[#ffb59c] animate-energy-ring pointer-events-none z-[9998]';
  ring.style.width = `${rect.width * 0.9}px`;
  ring.style.height = `${rect.height * 0.9}px`;
  ring.style.left = `${rect.left + rect.width / 2}px`;
  ring.style.top = `${rect.top + rect.height / 2}px`;

  document.body.appendChild(ring);
  setTimeout(() => {
    if (ring.parentNode) ring.parentNode.removeChild(ring);
  }, 650);
}

export function triggerFloatingChip(targetElement: HTMLElement, text: string, styleClasses: string) {
  const rect = targetElement.getBoundingClientRect();
  const chip = document.createElement('div');
  chip.className = `fixed z-[9999] px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide flex items-center gap-1.5 animate-float-chip backdrop-blur-xl shadow-[0_8px_32px_rgba(0,0,0,0.36)] pointer-events-none select-none ${styleClasses}`;
  chip.innerHTML = text;
  chip.style.left = `${rect.left + rect.width / 2}px`;
  chip.style.top = `${rect.top}px`;

  document.body.appendChild(chip);
  setTimeout(() => {
    if (chip.parentNode) chip.parentNode.removeChild(chip);
  }, 1450);
}

interface SrsDockCapsuleProps {
  onRate?: (rating: 'hard' | 'easy') => void;
  phraseSpanish?: string;
  className?: string;
}

export const SrsDockCapsule: React.FC<SrsDockCapsuleProps> = ({
  onRate,
  phraseSpanish,
  className = '',
}) => {
  const [isDismissed, setIsDismissed] = useState(false);

  // When current phrase changes, smoothly reveal the buttons for the new phrase
  useEffect(() => {
    setIsDismissed(false);
  }, [phraseSpanish]);

  const handleRate = (rating: 'hard' | 'easy', e: React.MouseEvent<HTMLButtonElement>) => {
    const btn = e.currentTarget;
    triggerHaptic(rating === 'easy' ? 'medium' : 'light');

    if (rating === 'easy') {
      playMasteryChime();
      triggerSparkleBurst(btn);
      triggerFloatingChip(
        btn,
        '<span class="material-symbols-outlined text-[15px] material-symbols-fill text-[#d6e9c1]">verified</span><span>Mastered (+4d)</span>',
        'bg-[#3a492c]/95 text-[#d6e9c1] border border-[#d6e9c1]/60 shadow-[0_8px_24px_rgba(58,73,44,0.4)]'
      );
    } else {
      playHardRecoil();
      triggerEnergyRing(btn);
      triggerFloatingChip(
        btn,
        '<span class="material-symbols-outlined text-[15px] material-symbols-fill text-[#ffb59c]">schedule</span><span>Requeued (10m)</span>',
        'bg-[#9f3c16]/95 text-[#ffc9b7] border border-[#ffdbcf]/60 shadow-[0_8px_24px_rgba(159,60,22,0.4)]'
      );
    }

    setIsDismissed(true);
    if (onRate) onRate(rating);
  };

  return (
    <AnimatePresence>
      {!isDismissed && (
        <motion.div
          id="srs-dock-capsule"
          initial={{ opacity: 0, y: 14, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{
            opacity: 0,
            scale: 0.88,
            y: 8,
            height: 0,
            minHeight: 0,
            paddingTop: 0,
            paddingBottom: 0,
            marginTop: 0,
            marginBottom: 0,
            borderWidth: 0,
            transition: { duration: 0.28, ease: [0.16, 1, 0.3, 1] },
          }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className={`relative w-full max-w-sm rounded-full bg-[#31302d]/95 text-[#f3f0eb] shadow-[0_8px_24px_rgba(0,0,0,0.3)] px-1.5 py-1 flex items-center justify-between backdrop-blur-xl border border-white/10 overflow-hidden min-h-[52px] ${className}`}
        >
          {/* Hard Action Button */}
          <motion.button
            aria-label="Rate phrase as hard (repeat in 10 minutes)"
            id="btn-rate-hard"
            whileTap={{ scale: 0.94 }}
            onClick={(e) => handleRate('hard', e)}
            className="group relative flex-1 min-h-[44px] px-3.5 rounded-full border border-[#bf542c]/50 text-[#ffdbcf] text-xs font-semibold flex items-center justify-center gap-1.5 shadow-sm transition-all focus:outline-none bg-[#9f3c16] hard-shimmer-active overflow-hidden cursor-pointer"
          >
            <span
              id="icon-rate-hard"
              className="material-symbols-outlined text-base text-[#ffb59c] group-hover:rotate-90 transition-transform inline-block"
            >
              close
            </span>
            <span className="truncate">Hard (10m)</span>
          </motion.button>

          {/* Easy Action Button */}
          <motion.button
            aria-label="Rate phrase as easy (spaced 4 days)"
            id="btn-rate-easy"
            whileTap={{ scale: 0.94 }}
            onClick={(e) => handleRate('easy', e)}
            className="group relative flex-1 min-h-[44px] px-3.5 rounded-full border border-[#d6e9c1]/50 text-[#d6e9c1] text-xs font-semibold flex items-center justify-center gap-1.5 shadow-sm transition-all focus:outline-none bg-[#516142] easy-breathe-glow cursor-pointer ml-1.5"
          >
            <span
              id="icon-rate-easy"
              className="material-symbols-outlined text-base text-[#d6e9c1] group-hover:scale-115 transition-transform inline-block material-symbols-fill"
            >
              done
            </span>
            <span className="truncate">Easy (+4d)</span>
          </motion.button>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
