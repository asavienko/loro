import React from 'react';
import { ScreenType } from '../types';

interface BottomNavBarProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  currentScreen,
  onNavigate,
}) => {
  const tabs: { id: ScreenType; label: string; icon: string }[] = [
    { id: 'rhythm', label: 'Rhythm', icon: 'graphic_eq' },
    { id: 'explore', label: 'Explore', icon: 'explore' },
    { id: 'library', label: 'Library', icon: 'history' },
  ];

  return (
    <nav
      id="bottom-nav"
      className="fixed bottom-0 inset-x-0 z-40 h-12 sm:h-13 bg-[#faf8f5]/90 backdrop-blur-md border-t border-[#ebe7e0]/70 select-none"
    >
      <div className="h-full flex justify-center items-center gap-2 sm:gap-4 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {tabs.map((tab) => {
          const isActive = currentScreen === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onNavigate(tab.id)}
              className={`h-full flex flex-col items-center justify-center w-18 sm:w-20 transition-all cursor-pointer active:scale-95 ${
                isActive
                  ? 'text-[#822701] font-semibold'
                  : 'text-[#635d59] hover:text-[#1c1c19] hover:bg-[#f0ede9]/40 font-medium'
              }`}
              type="button"
            >
              <div
                className={`flex flex-col items-center justify-center py-0.5 px-3 rounded-lg ${
                  isActive ? 'bg-[#f5f2ed] border border-[#dec0b7]/50 shadow-2xs' : ''
                }`}
              >
                <span
                  className={`material-symbols-outlined text-[18px] sm:text-[19px] leading-none ${
                    isActive ? 'text-[#9f3c16] material-symbols-fill' : 'text-[#8a726a]'
                  }`}
                >
                  {tab.icon}
                </span>
                <span className="text-[10px] tracking-tight leading-tight mt-0.5">
                  {tab.label}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
