import React, { useState, useRef } from 'react';
import { motion, useMotionValue, useAnimationControls, PanInfo } from 'motion/react';
import { Phrase } from '../types';
import { SAMPLE_PHRASES } from '../data/mockData';
import { playPorcelainTap, triggerHaptic } from '../utils/audioEngine';

interface MiniPlayerProps {
  currentPhrase: Phrase;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onNext: () => void;
  onPrevious?: () => void;
  playbackSpeed: number;
  onToggleSpeed: () => void;
  onOpenPlayer: () => void;
}

export const MiniPlayer: React.FC<MiniPlayerProps> = ({
  currentPhrase,
  isPlaying,
  onTogglePlay,
  onNext,
  onPrevious,
  playbackSpeed,
  onToggleSpeed,
  onOpenPlayer,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const isTransitioningRef = useRef(false);
  const controls = useAnimationControls();
  const dragX = useMotionValue(0);

  // Find adjacent phrases for smooth continuous carousel slider
  const allPhrases = SAMPLE_PHRASES;
  const currentIndex = allPhrases.findIndex((p) => p.id === currentPhrase.id);
  const nextPhrase =
    currentIndex >= 0 ? allPhrases[(currentIndex + 1) % allPhrases.length] : allPhrases[0];
  const prevPhrase =
    currentIndex >= 0
      ? allPhrases[(currentIndex - 1 + allPhrases.length) % allPhrases.length]
      : allPhrases[allPhrases.length - 1];

  const triggerNext = () => {
    onNext();
  };

  const triggerPrev = () => {
    if (onPrevious) {
      onPrevious();
    } else {
      onNext();
    }
  };

  const handleDragEnd = async (
    _e: MouseEvent | TouchEvent | PointerEvent,
    info: PanInfo
  ) => {
    setIsDragging(false);
    if (isTransitioningRef.current) return;

    const offsetX = info.offset.x;
    const velocityX = info.velocity.x;

    // Responsive swipe detection (swiped left -> next song)
    if (offsetX < -35 || velocityX < -200) {
      isTransitioningRef.current = true;
      playPorcelainTap(1500);
      // Animate card smoothly sliding left into position
      await controls.start({
        x: -360,
        transition: { duration: 0.18, ease: 'easeOut' },
      });
      triggerNext();
      // Reset position immediately for new active song
      dragX.set(0);
      await controls.set({ x: 0 });
      isTransitioningRef.current = false;
    } else if (offsetX > 35 || velocityX > 200) {
      isTransitioningRef.current = true;
      playPorcelainTap(1200);
      // Animate card smoothly sliding right into position
      await controls.start({
        x: 360,
        transition: { duration: 0.18, ease: 'easeOut' },
      });
      triggerPrev();
      // Reset position immediately for new active song
      dragX.set(0);
      await controls.set({ x: 0 });
      isTransitioningRef.current = false;
    } else {
      // Snap back smoothly to center if swipe wasn't strong enough
      controls.start({
        x: 0,
        transition: { type: 'spring', stiffness: 500, damping: 35 },
      });
    }
  };

  const handleContainerTap = (
    _event: MouseEvent | TouchEvent | PointerEvent,
    info?: { point: { x: number; y: number } }
  ) => {
    // Check what element was clicked/tapped
    const activeEl = document.activeElement as HTMLElement | null;
    if (activeEl && activeEl.closest('button, [data-interactive="true"]')) {
      return;
    }
    const target = (_event?.target as HTMLElement | null);
    if (target && target.closest('button, [data-interactive="true"]')) {
      return;
    }
    // Also check point under cursor if info is provided
    if (info?.point) {
      const elementAtPoint = document.elementFromPoint(info.point.x, info.point.y);
      if (elementAtPoint && elementAtPoint.closest('button, [data-interactive="true"]')) {
        return;
      }
    }
    if (!isDragging && !isTransitioningRef.current && Math.abs(dragX.get()) < 6) {
      playPorcelainTap(1400);
      onOpenPlayer();
    }
  };

  const renderCardContent = (
    phrase: Phrase,
    isCurrent: boolean,
    tagLabel?: string
  ) => (
    <div className="w-full h-full rounded-2xl bg-[#31302d]/98 text-[#f3f0eb] shadow-2xl p-2.5 pt-2 flex flex-col backdrop-blur-md border border-white/10 select-none">
      {/* Top Handle */}
      <div className="w-full flex items-center justify-center mb-1.5 pointer-events-none">
        <div className="w-9 h-1 rounded-full bg-white/25" />
      </div>

      <div className="w-full flex items-center justify-between">
        {/* Thumbnail & Drill Text */}
        <div className="flex items-center gap-2.5 min-w-0 flex-1 group">
          <div className="relative w-11 h-11 shrink-0 rounded-lg overflow-hidden bg-[#f0ede9]">
            <img
              className="w-full h-full object-cover"
              alt={phrase.spanish}
              src={
                phrase.coverImage ||
                'https://lh3.googleusercontent.com/aida-public/AB6AXuARSyqQjTe5OmRftOyRB6H9s9wCyY5mCYRtT88IO34sB7wGNZV843oE2LUC-Ex7kYotb12IZBze34zwIT2C06XpwvX7UZniovVCMqL9JaI-bgg5YxIVvLEzaVGHDec0yUh5fEaH7Cnb_iqDBRQANjWsgC2ZyyaFmbgDNNj9IKk1SRYua-Usd12teGsvq4_cZQ4vOK5_3udfWubTQSTkK1yGQSdzIcQa4Ax11KMzQZK3n-s_ay_KpnAfPg'
              }
              referrerPolicy="no-referrer"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src =
                  'https://lh3.googleusercontent.com/aida-public/AB6AXuARSyqQjTe5OmRftOyRB6H9s9wCyY5mCYRtT88IO34sB7wGNZV843oE2LUC-Ex7kYotb12IZBze34zwIT2C06XpwvX7UZniovVCMqL9JaI-bgg5YxIVvLEzaVGHDec0yUh5fEaH7Cnb_iqDBRQANjWsgC2ZyyaFmbgDNNj9IKk1SRYua-Usd12teGsvq4_cZQ4vOK5_3udfWubTQSTkK1yGQSdzIcQa4Ax11KMzQZK3n-s_ay_KpnAfPg';
              }}
            />
            {isCurrent && isPlaying && (
              <div className="absolute inset-0 bg-[#7f2500]/30 flex items-center justify-center">
                <span className="material-symbols-outlined text-white text-base animate-pulse">
                  volume_up
                </span>
              </div>
            )}
          </div>

          <div className="flex flex-col min-w-0 pr-1 overflow-hidden justify-center">
            <div className="overflow-hidden w-full relative whitespace-nowrap">
              <p className="font-serif italic text-sm text-[#f3f0eb] leading-tight animate-running-string">
                <span className="pr-8">{phrase.spanish}</span>
                <span className="pr-8" aria-hidden="true">{phrase.spanish}</span>
              </p>
            </div>
            <span className="text-xs text-[#cdc5c0] truncate">
              {phrase.english || 'Castilian Madrid • Clara & Sara'}
            </span>
          </div>
        </div>

        {/* Direct Playback Controls */}
        <div
          data-interactive="true"
          onClick={(e) => e.stopPropagation()}
          onPointerDown={(e) => e.stopPropagation()}
          onPointerUp={(e) => e.stopPropagation()}
          className="flex items-center gap-1 shrink-0 ml-2"
        >
          {isCurrent ? (
            <>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleSpeed();
                }}
                onPointerDown={(e) => e.stopPropagation()}
                onPointerUp={(e) => e.stopPropagation()}
                className="w-8 h-8 rounded-full bg-[#31302d] hover:bg-white/10 flex items-center justify-center text-[#f3f0eb] active:scale-90 transition-transform cursor-pointer"
                title="Toggle Speed"
                type="button"
              >
                <span className="font-mono font-bold text-xs">{playbackSpeed}x</span>
              </button>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  playPorcelainTap(1200);
                  triggerHaptic('medium');
                  triggerPrev();
                }}
                onPointerDown={(e) => e.stopPropagation()}
                onPointerUp={(e) => e.stopPropagation()}
                aria-label="Previous song"
                className="w-8 h-8 rounded-full bg-[#31302d] hover:bg-white/10 flex items-center justify-center text-[#f3f0eb] active:scale-90 transition-transform cursor-pointer"
                title="Previous song"
                type="button"
              >
                <span className="material-symbols-outlined text-lg">skip_previous</span>
              </button>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  triggerHaptic('medium');
                  onTogglePlay();
                }}
                onPointerDown={(e) => e.stopPropagation()}
                onPointerUp={(e) => e.stopPropagation()}
                aria-label={isPlaying ? 'Pause' : 'Play'}
                className="w-9 h-9 rounded-full bg-[#ffdbcf] text-[#390c00] flex items-center justify-center active:scale-90 transition-transform shadow-sm cursor-pointer"
                type="button"
              >
                <span className="material-symbols-outlined text-xl material-symbols-fill">
                  {isPlaying ? 'pause' : 'play_arrow'}
                </span>
              </button>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  playPorcelainTap(1500);
                  triggerHaptic('medium');
                  triggerNext();
                }}
                onPointerDown={(e) => e.stopPropagation()}
                onPointerUp={(e) => e.stopPropagation()}
                aria-label="Skip to next phrase"
                className="w-8 h-8 rounded-full bg-[#31302d] hover:bg-white/10 flex items-center justify-center text-[#f3f0eb] active:scale-90 transition-transform cursor-pointer"
                title="Next song"
                type="button"
              >
                <span className="material-symbols-outlined text-lg">skip_next</span>
              </button>
            </>
          ) : (
            <div className="flex items-center gap-1 opacity-70">
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-[#f3f0eb]">
                <span className="material-symbols-outlined text-lg">
                  {tagLabel === 'Previous' ? 'skip_previous' : 'skip_next'}
                </span>
              </div>
              <div className="w-9 h-9 rounded-full bg-[#ffdbcf] text-[#390c00] flex items-center justify-center shadow-sm">
                <span className="material-symbols-outlined text-xl material-symbols-fill">
                  play_arrow
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="relative w-full select-none overflow-hidden rounded-2xl">
      {/* 3-Card Carousel Track Slider */}
      <motion.div
        key={currentPhrase.id}
        style={{ x: dragX }}
        animate={controls}
        drag="x"
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={0.65}
        onDragStart={() => setIsDragging(true)}
        onDragEnd={handleDragEnd}
        onTap={handleContainerTap}
        whileTap={{ scale: 0.99 }}
        className="relative w-full cursor-pointer active:cursor-grabbing touch-pan-y"
      >
        {/* Left / Previous Card (positioned just outside to the left) */}
        <div className="absolute top-0 right-[calc(100%+12px)] w-full h-full pointer-events-none">
          {renderCardContent(prevPhrase, false, 'Previous')}
        </div>

        {/* Center / Current Active Card */}
        <div className="w-full">
          {renderCardContent(currentPhrase, true)}
        </div>

        {/* Right / Next Card (positioned just outside to the right) */}
        <div className="absolute top-0 left-[calc(100%+12px)] w-full h-full pointer-events-none">
          {renderCardContent(nextPhrase, false, 'Next Up')}
        </div>
      </motion.div>
    </div>
  );
};
