import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CadencePack } from '../types';
import { playPorcelainTap, playMasteryChime, triggerHaptic } from '../utils/audioEngine';

export type DownloadState = 'idle' | 'downloading' | 'downloaded';

interface PackDownloadButtonProps {
  pack: CadencePack;
  onDownloadComplete?: () => void;
  onRemoveFromCache?: () => void;
  className?: string;
}

export const PackDownloadButton: React.FC<PackDownloadButtonProps> = ({
  pack,
  onDownloadComplete,
  onRemoveFromCache,
  className = '',
}) => {
  // Initial state is strictly 'idle' (download icon) per user specification
  const [downloadState, setDownloadState] = useState<DownloadState>('idle');
  const [progress, setProgress] = useState(0);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const toastTimeoutRef = useRef<number | null>(null);

  // Close dropdown on click outside or Escape
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent | TouchEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsMenuOpen(false);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsMenuOpen(false);
      }
    };

    if (isMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('touchstart', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('touchstart', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isMenuOpen]);

  const showToast = (msg: string) => {
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    setToastMessage(msg);
    toastTimeoutRef.current = window.setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  const handleButtonClick = () => {
    if (downloadState === 'idle') {
      // Start download
      playPorcelainTap(1300);
      triggerHaptic('medium');
      setDownloadState('downloading');
      setProgress(10);

      // Animate download progress smoothly over ~1.6s
      const steps = [
        { pct: 28, delay: 280 },
        { pct: 58, delay: 650 },
        { pct: 85, delay: 1100 },
        { pct: 100, delay: 1550 },
      ];

      steps.forEach(({ pct, delay }) => {
        setTimeout(() => {
          setProgress(pct);
          if (pct < 100) {
            playPorcelainTap(1100 + pct * 5, 0.04);
          } else {
            // Download completed!
            setTimeout(() => {
              setDownloadState('downloaded');
              playMasteryChime();
              triggerHaptic('success');
              showToast('Downloaded! Stored for offline play 🎧');
              onDownloadComplete?.();
            }, 250);
          }
        }, delay);
      });
    } else if (downloadState === 'downloaded') {
      // Toggle cache details menu
      playPorcelainTap(1500);
      triggerHaptic('selection');
      setIsMenuOpen((prev) => !prev);
    }
  };

  const handleRemove = () => {
    playPorcelainTap(900);
    triggerHaptic('medium');
    setDownloadState('idle');
    setProgress(0);
    setIsMenuOpen(false);
    showToast(`Removed from cache • ${pack.cachedSize || '18.4 MB'} freed`);
    onRemoveFromCache?.();
  };

  return (
    <div className={`relative inline-block ${className}`} ref={menuRef}>
      {/* Main Action Button */}
      <button
        id="pack-download-btn"
        type="button"
        onClick={handleButtonClick}
        disabled={downloadState === 'downloading'}
        aria-label={
          downloadState === 'idle'
            ? 'Download cadence pack for offline practice'
            : downloadState === 'downloading'
            ? `Downloading ${progress}%`
            : 'Downloaded offline. Click for cache settings'
        }
        aria-expanded={isMenuOpen}
        aria-haspopup="dialog"
        title={
          downloadState === 'idle'
            ? 'Download for offline play'
            : downloadState === 'downloading'
            ? `Downloading ${progress}%`
            : 'Downloaded • Click for cache options'
        }
        className={`relative flex items-center justify-center transition-all duration-200 select-none ${
          downloadState === 'downloaded'
            ? 'w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#d6e9c1] text-[#20440f] border border-[#a8cc89] shadow-2xs hover:bg-[#cbe2b4] active:scale-95 cursor-pointer'
            : downloadState === 'downloading'
            ? 'w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#f0ede9] text-[#9f3c16] border border-[#dec0b7]/60 shadow-2xs cursor-wait'
            : 'w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#f0ede9] hover:bg-[#eae6e0] active:scale-95 text-[#57423b] hover:text-[#1c1c19] border border-[#dec0b7]/50 shadow-2xs cursor-pointer'
        }`}
      >
        {/* Initial State: Download Icon */}
        {downloadState === 'idle' && (
          <span className="material-symbols-outlined text-xl transition-transform group-hover:scale-105">
            download
          </span>
        )}

        {/* Downloading State: Animated Circular Progress Ring + Arrow */}
        {downloadState === 'downloading' && (
          <div className="relative w-full h-full flex items-center justify-center">
            <svg className="w-8 h-8 -rotate-90" viewBox="0 0 36 36">
              <circle
                cx="18"
                cy="18"
                r="15"
                className="text-[#dec0b7]/40"
                strokeWidth="2.5"
                stroke="currentColor"
                fill="none"
              />
              <circle
                cx="18"
                cy="18"
                r="15"
                className="text-[#9f3c16] transition-all duration-300 ease-out"
                strokeWidth="2.5"
                strokeDasharray="94.2"
                strokeDashoffset={94.2 - (94.2 * progress) / 100}
                strokeLinecap="round"
                stroke="currentColor"
                fill="none"
              />
            </svg>
            <span className="absolute material-symbols-outlined text-[15px] text-[#9f3c16] animate-bounce">
              arrow_downward
            </span>
          </div>
        )}

        {/* Downloaded State: Green Checkmark */}
        {downloadState === 'downloaded' && (
          <motion.div
            initial={{ scale: 0.6, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', stiffness: 400, damping: 20 }}
            className="flex items-center justify-center"
          >
            <span className="material-symbols-outlined text-xl material-symbols-fill text-[#20440f]">
              check_circle
            </span>
          </motion.div>
        )}
      </button>

      {/* Cache Settings Dropdown / Popover */}
      <AnimatePresence>
        {isMenuOpen && downloadState === 'downloaded' && (
          <motion.div
            initial={{ opacity: 0, y: 6, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 4, scale: 0.96 }}
            transition={{ duration: 0.18, ease: 'easeOut' }}
            className="absolute top-full right-0 mt-2 w-72 sm:w-80 bg-[#ffffff] border border-[#dec0b7]/70 rounded-2xl p-4 shadow-xl z-50 flex flex-col gap-3.5 text-[#1c1c19]"
            role="dialog"
            aria-label="Offline Cache Settings"
          >
            {/* Header with Close */}
            <div className="flex items-center justify-between border-b border-[#ebe8e3] pb-2.5">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#3a492c] animate-pulse" />
                <span className="text-xs font-bold uppercase tracking-wider text-[#1c1c19]">
                  Offline Cache
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsMenuOpen(false)}
                className="w-6 h-6 rounded-full flex items-center justify-center text-[#8a726a] hover:text-[#1c1c19] hover:bg-[#f6f3ee] transition-colors"
                aria-label="Close cache options"
              >
                <span className="material-symbols-outlined text-base">close</span>
              </button>
            </div>

            {/* Pack & Cache Details */}
            <div className="bg-[#fcfaf7] border border-[#dec0b7]/40 rounded-xl p-3 flex flex-col gap-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs text-[#635d59] font-medium">Cache Size</span>
                <span className="text-xs font-mono font-bold text-[#20440f] bg-[#d6e9c1]/70 px-2 py-0.5 rounded-md">
                  {pack.cachedSize || '18.4 MB Cached'}
                </span>
              </div>
              <div className="flex items-center justify-between text-[11px] text-[#635d59]">
                <span>Storage Status</span>
                <span className="font-semibold text-[#1c1c19]">Zero-Latency Offline Ready</span>
              </div>
              <p className="text-[11px] text-[#8a726a] mt-0.5 leading-snug">
                All 6 phrase tracks, IPA spectrograms, and auditory prosody loops are stored locally on your device.
              </p>
            </div>

            {/* Remove From Cache Button */}
            <button
              id="remove-from-cache-btn"
              type="button"
              onClick={handleRemove}
              className="w-full py-2.5 px-3 rounded-xl bg-[#ffdbcf]/70 hover:bg-[#ffdbcf] text-[#822701] font-semibold text-xs flex items-center justify-center gap-2 border border-[#dec0b7]/50 active:scale-98 transition-all cursor-pointer shadow-2xs group"
            >
              <span className="material-symbols-outlined text-base text-[#9f3c16] group-hover:rotate-12 transition-transform">
                delete_outline
              </span>
              <span>Remove from cache</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Status Toast */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.95 }}
            className="fixed top-18 right-4 sm:right-8 z-50 pointer-events-none bg-[#1c1c19] text-[#ffffff] px-3.5 py-2 rounded-xl text-xs font-semibold shadow-lg border border-[#393532]/40 flex items-center gap-2"
          >
            <span className="material-symbols-outlined text-sm text-[#d6e9c1]">info</span>
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
