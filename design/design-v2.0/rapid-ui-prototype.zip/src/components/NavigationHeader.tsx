import React from 'react';
import { CURRENT_USER } from '../data/mockData';

interface NavigationHeaderProps {
  title?: string;
  showBack?: boolean;
  onBack?: () => void;
  showStreak?: boolean;
  onProfileClick?: () => void;
  rightAction?: React.ReactNode;
}

export const NavigationHeader: React.FC<NavigationHeaderProps> = ({
  title,
  showBack = false,
  onBack,
  showStreak = true,
  onProfileClick,
  rightAction,
}) => {
  return (
    <header className="fixed top-0 inset-x-0 z-40 bg-[#faf8f5]/90 backdrop-blur-md border-b border-[#ebe7e0]/70">
      <div className="h-14 sm:h-16 px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-3 max-w-5xl mx-auto">
        <div className="flex items-center gap-2.5 min-w-0">
          {showBack && (
            <button
              aria-label="Go back"
              onClick={onBack}
              className="w-9 h-9 flex items-center justify-center rounded-full text-[#1c1c19] hover:bg-[#ebe7e0]/60 active:scale-95 transition-all -ml-1 cursor-pointer shrink-0"
              type="button"
            >
              <span className="material-symbols-outlined text-xl">arrow_back</span>
            </button>
          )}

          {/* User Logo at the beginning of the row */}
          <button
            aria-label="Profile"
            onClick={onProfileClick}
            className="w-8 h-8 rounded-full overflow-hidden ring-1 ring-[#dec0b7]/60 hover:ring-[#9f3c16]/50 active:scale-95 transition-all cursor-pointer shadow-2xs shrink-0"
            type="button"
          >
            <img
              alt="Profile avatar"
              className="w-full h-full object-cover"
              src={CURRENT_USER.avatar}
              referrerPolicy="no-referrer"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src =
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80';
              }}
            />
          </button>

          {/* Points right after user logo */}
          {showStreak && (
            <div className="flex items-center gap-1 bg-[#f5f2ed] border border-[#dec0b7]/40 px-2.5 py-1 rounded-full text-[#822701] text-xs font-semibold shrink-0">
              <span className="material-symbols-outlined text-[14px] text-[#9f3c16] material-symbols-fill">
                local_fire_department
              </span>
              <span className="font-mono text-xs font-bold">{CURRENT_USER.streak}</span>
              <span className="text-[10px] text-[#8a726a] font-medium hidden xs:inline">pts</span>
            </div>
          )}

          {/* Screen Title (when on a subscreen) */}
          {title && (
            <h1 className="font-serif font-semibold text-base sm:text-lg text-[#1c1c19] truncate tracking-tight ml-1">
              {title}
            </h1>
          )}
        </div>

        {/* Top Right Corner Action Slot */}
        {rightAction && (
          <div className="flex items-center gap-2 shrink-0 ml-auto">
            {rightAction}
          </div>
        )}
      </div>
    </header>
  );
};
