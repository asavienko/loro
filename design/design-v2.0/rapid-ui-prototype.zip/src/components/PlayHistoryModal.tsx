import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phrase } from '../types';
import { playPorcelainTap, speakSpanishPhrase } from '../utils/audioEngine';

export interface PlayedSetHistoryItem {
  id: string;
  packId: string;
  packTitle: string;
  sessionTitle: string;
  playedAt: string;
  duration: string;
  repsCompleted: number;
  accuracy: number;
  bpm: number;
  coverImage: string;
  phrasesPlayed: {
    spanish: string;
    english: string;
    status: 'mastered' | 'review' | 'practiced';
    time: string;
  }[];
}

export const PLAYED_SETS_HISTORY: PlayedSetHistoryItem[] = [
  {
    id: 'set-hist-1',
    packId: 'pack-cafe-mananas',
    packTitle: 'Café & Mañanas (Vol. 03)',
    sessionTitle: 'Matinal Rapid Orders Session',
    playedAt: 'Today, 08:24 AM',
    duration: '6m 12s',
    repsCompleted: 14,
    accuracy: 94,
    bpm: 118,
    coverImage: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBpYjBAsi4EEY5kyiYM-TQhpZHpoerlAmg38carBrnRXzKZhEvUq1oZri29rAxj2tg3Z54cpjqc490e4NjsfC0zSSkG5eHWH_fmLRVCZ1CZlOsYg9NNBNS4oohWMrsIVYXkhwYumfVAjx1DcNya9FErRQa8LdsVgjm7PO-wJihT_p-B2t0IHo2niPjGL_JAx7GIc5oJGscNbm-LwfjAPof770GUAfaL7t3z9uWo34dMr72hcDa8gUMgAQ',
    phrasesPlayed: [
      { spanish: '«Me pone un cortado, por favor»', english: 'A cortado for me, please', status: 'mastered', time: '08:29' },
      { spanish: '«Con leche templada de avena»', english: 'With lukewarm oat milk', status: 'mastered', time: '08:27' },
      { spanish: '«¿Tiene sacarina o azúcar moreno?»', english: 'Do you have sweetener or brown sugar?', status: 'practiced', time: '08:26' },
      { spanish: '«¿Cuánto le debo?»', english: 'How much do I owe you?', status: 'review', time: '08:25' },
      { spanish: '«Para tomar aquí en barra, gracias»', english: 'To have here at the bar, thanks', status: 'mastered', time: '08:24' },
      { spanish: '«Una tostada con tomate y aceite»', english: 'Toast with tomato and olive oil', status: 'practiced', time: '08:22' },
      { spanish: '«¿Me pone un vaso de agua del grifo?»', english: 'Could you give me a glass of tap water?', status: 'review', time: '08:21' },
      { spanish: '«Quédese con la vuelta, jefe»', english: 'Keep the change, boss', status: 'mastered', time: '08:20' },
    ],
  },
  {
    id: 'set-hist-2',
    packId: 'pack-tapas',
    packTitle: 'Tapas Crawl & Bodegas',
    sessionTitle: 'Madrid Counter Slang Drills',
    playedAt: 'Yesterday, 07:15 PM',
    duration: '8m 45s',
    repsCompleted: 18,
    accuracy: 88,
    bpm: 104,
    coverImage: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDvuB7CJxb83WZXA9hzal1SDMaT0lVF-VgUZss3cSGGMJ1wKT6x9x-oCGEqNVp2-ZtNcLRHVWfE4PR1HNL8tdS2yuaurtgwKvfO-IaoPOfJq-uxmFzCkUGL2SemcqyIlsGZGwxn073061X-lm81VbPQfpytB6DKeER-0VXGlYDPEo96L8KJ_aoWeFJAEKy_bZlDP1jWQRa4kArt6--UcXGyJ7sCl-i0QJvt8AgwKpbgKtvlIxsn0F_hLQ',
    phrasesPlayed: [
      { spanish: '«Una caña bien tirada, jefe»', english: 'A properly poured draft beer, boss', status: 'mastered', time: '19:22' },
      { spanish: '«¿Qué tapa tenéis hoy de aperitivo?»', english: 'What complimentary tapa do you have today?', status: 'practiced', time: '19:20' },
      { spanish: '«Nos cobra cuando pueda, por favor»', english: 'Charge us whenever you can, please', status: 'mastered', time: '19:17' },
      { spanish: '«Ponme otra ronda cuando puedas»', english: 'Bring us another round when you can', status: 'review', time: '19:15' },
      { spanish: '«¿La tortilla es con o sin cebolla?»', english: 'Is the Spanish omelet with or without onion?', status: 'mastered', time: '19:12' },
      { spanish: '«La cuenta, por favor, que nos vamos»', english: 'The bill, please, as we are leaving', status: 'practiced', time: '19:08' },
    ],
  },
  {
    id: 'set-hist-3',
    packId: 'pack-metro',
    packTitle: 'Metro Drift & Urban Transit',
    sessionTitle: 'Line 10 Commute Cadence Wave',
    playedAt: 'Sep 11, 01:10 PM',
    duration: '5m 30s',
    repsCompleted: 12,
    accuracy: 92,
    bpm: 126,
    coverImage: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBG-CRnGKgH15nTbRi7Zka7S2hYW1gJPRq8JDUud5hCp_2reJbaXLHL4sAllF-F-pcMxvsR2tx2FaH1pz_KAQFBrmhgfOWhs6jn7IhFC-bR6jVYYSb1BWYofDhvYS95pqf1NNt8FdgO1vAdwBkqw21f4xYoOoUsyNAPQG4BW12ToW9mC6xJXsP5KgWeE0a_YGrR-lPJUOxAFOoe-me1wZ46w62qGOY9bpXMdD8wqkTBm8HenYoSkaa7OA',
    phrasesPlayed: [
      { spanish: '«Disculpe, ¿este tren va hacia Tribunal?»', english: 'Excuse me, does this train go toward Tribunal?', status: 'mastered', time: '13:14' },
      { spanish: '«¿Pasa algo con la correspondencia?»', english: 'Is there an issue with the transfer?', status: 'practiced', time: '13:12' },
      { spanish: '«Permítame pasar, por favor, bajo aquí»', english: 'Pardon me, please, I get off here', status: 'mastered', time: '13:10' },
      { spanish: '«¿Dónde puedo recargar la tarjeta Multi?»', english: 'Where can I top up the transit card?', status: 'review', time: '13:08' },
      { spanish: '«Próxima estación con enlace a cercanías»', english: 'Next station with connection to regional trains', status: 'practiced', time: '13:05' },
    ],
  },
  {
    id: 'set-hist-4',
    packId: 'pack-sobremesa',
    packTitle: 'Sobremesa & Evening Talk',
    sessionTitle: 'Deep Retention Acoustic Imprint',
    playedAt: 'Sep 10, 09:40 PM',
    duration: '11m 20s',
    repsCompleted: 20,
    accuracy: 96,
    bpm: 92,
    coverImage: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCJEUz0Ds-_ZN3zFFyYjNstFcIpO2C10KV5oHP8NVYIBIRdiGvO-qsBDKCpF9uQj1ND93CymxfmEhFRMTYnn0S7nGJo0ARbhZhk6FjUDpZtmKIyem3L8ZuSPAgW3pirSEnqR4OJ5mPPefthkw-SGBxkg3_Bh4jm3ZUllpxI7Ia7wn8p8OdkIn6AfUYJzqGyxsSmgoVfFnt83G7LzVJQ_xtFy8ZhOZ5qQAExINoI0tSkYHjfiphhFXEYUg',
    phrasesPlayed: [
      { spanish: '«Ha sido una velada estupenda»', english: 'It has been a wonderful evening', status: 'mastered', time: '21:49' },
      { spanish: '«¿Nos tomamos la última de pie?»', english: 'Shall we have the last drink standing up?', status: 'mastered', time: '21:45' },
      { spanish: '«La comida estaba realmente exquisita»', english: 'The food was truly exquisite', status: 'mastered', time: '21:42' },
      { spanish: '«Invito yo a esta ronda de sobremesa»', english: 'This post-meal round is on me', status: 'review', time: '21:38' },
      { spanish: '«Mañana nos vemos a la misma hora»', english: 'See you tomorrow at the same time', status: 'practiced', time: '21:35' },
    ],
  },
];

interface PlayHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPack: (packId: string) => void;
  onPlayPhrase?: (phrase: Phrase) => void;
}

export const PlayHistoryModal: React.FC<PlayHistoryModalProps> = ({
  isOpen,
  onClose,
  onSelectPack,
}) => {
  const [expandedSetId, setExpandedSetId] = React.useState<string | null>('set-hist-1');

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => {
            playPorcelainTap(1200);
            onClose();
          }}
          className="fixed inset-0 bg-[#1c1c19]/40 backdrop-blur-xs"
        />

        {/* Modal Sheet */}
        <motion.div
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 60 }}
          transition={{ duration: 0.24, ease: 'easeOut' }}
          className="relative w-full max-w-lg bg-[#fcf9f4] rounded-t-3xl sm:rounded-3xl shadow-2xl border border-[#dec0b7]/40 max-h-[88vh] flex flex-col overflow-hidden z-10 select-none"
        >
          {/* Grab Handle */}
          <div className="w-12 h-1.5 rounded-full bg-[#dec0b7] mx-auto mt-2.5 mb-1 opacity-80" />

          {/* Header */}
          <div className="flex items-center justify-between px-5 py-3 border-b border-[#f0ede9]">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[#9f3c16] text-xl">
                history
              </span>
              <div>
                <h3 className="font-serif text-lg font-semibold text-[#1c1c19]">
                  Previously Played Sets
                </h3>
                <p className="text-[11px] text-[#635d59]">
                  Session timeline and prosody rehearsal archives
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                playPorcelainTap(1100);
                onClose();
              }}
              className="w-8 h-8 rounded-full flex items-center justify-center text-[#635d59] hover:bg-[#ebe8e3] active:scale-95 transition-transform"
              type="button"
              aria-label="Close history"
            >
              <span className="material-symbols-outlined text-lg">close</span>
            </button>
          </div>

          {/* List of sets played */}
          <div className="flex-1 overflow-y-auto px-5 py-3.5 space-y-3.5">
            {PLAYED_SETS_HISTORY.map((item) => {
              const isExpanded = expandedSetId === item.id;
              return (
                <div
                  key={item.id}
                  className="bg-[#ffffff] border border-[#dec0b7]/50 rounded-2xl p-3.5 shadow-2xs hover:border-[#bf542c]/40 transition-all flex flex-col space-y-3"
                >
                  <div className="flex items-start gap-3">
                    <img
                      src={item.coverImage}
                      alt={item.packTitle}
                      className="w-13 h-13 rounded-xl object-cover shrink-0 shadow-2xs border border-[#dec0b7]/30"
                      referrerPolicy="no-referrer"
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-[#9f3c16]">
                          {item.playedAt}
                        </span>
                        <div className="flex items-center gap-1 text-[11px] font-bold text-[#3a492c]">
                          <span className="material-symbols-outlined text-[13px]">
                            verified
                          </span>
                          <span>{item.accuracy}%</span>
                        </div>
                      </div>

                      <h4 className="text-sm font-semibold text-[#1c1c19] truncate mt-0.5">
                        {item.packTitle}
                      </h4>
                      <p className="text-xs text-[#635d59] truncate">
                        {item.sessionTitle}
                      </p>
                    </div>
                  </div>

                  {/* Badges & Metrics Bar */}
                  <div className="flex items-center justify-between bg-[#f8f6f2] rounded-xl px-3 py-1.5 text-xs text-[#57423b]">
                    <div className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-sm text-[#9f3c16]">
                        speed
                      </span>
                      <span className="font-semibold text-[11px]">{item.bpm} BPM</span>
                      <span className="text-[#dec0b7]">•</span>
                      <span className="text-[11px]">{item.duration}</span>
                    </div>

                    <div className="flex items-center gap-1 text-[11px] font-semibold text-[#1c1c19]">
                      <span className="material-symbols-outlined text-sm text-[#9f3c16]">
                        replay
                      </span>
                      <span>{item.repsCompleted} reps</span>
                    </div>
                  </div>

                  {/* Expandable phrases list */}
                  {isExpanded && (
                    <div className="border-t border-[#f0ede9] pt-2.5 space-y-1.5">
                      <p className="text-[10px] font-bold uppercase tracking-wider text-[#635d59]">
                        Phrases in this set ({item.phrasesPlayed.length})
                      </p>
                      <div className="space-y-1.5 max-h-[196px] sm:max-h-[200px] overflow-y-auto pr-1.5 overscroll-contain scroll-smooth">
                        {item.phrasesPlayed.map((phrase, idx) => (
                          <div
                            key={idx}
                            onClick={() => {
                              playPorcelainTap(1300);
                              speakSpanishPhrase(phrase.spanish.replace(/[«»]/g, ''));
                            }}
                            className="flex items-center justify-between text-xs py-1.5 px-2.5 rounded-xl bg-[#fcf9f4] hover:bg-[#fff7f2] border border-[#dec0b7]/30 hover:border-[#bf542c]/40 transition-all cursor-pointer group active:scale-[0.99]"
                            title="Click to listen to phrase pronunciation"
                          >
                            <div className="min-w-0 flex-1 pr-2">
                              <p className="font-medium text-[#1c1c19] truncate group-hover:text-[#9f3c16] transition-colors">
                                {phrase.spanish}
                              </p>
                              <p className="text-[11px] text-[#635d59] truncate">
                                {phrase.english}
                              </p>
                            </div>
                            <div className="flex items-center gap-1.5 shrink-0">
                              <span className="text-[10px] font-mono text-[#8a726a]">
                                {phrase.time}
                              </span>
                              <span
                                className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full shrink-0 ${
                                  phrase.status === 'mastered'
                                    ? 'bg-[#d6e9c1] text-[#111f07]'
                                    : phrase.status === 'review'
                                    ? 'bg-[#ffdbcf] text-[#9f3c16]'
                                    : 'bg-[#ebe8e3] text-[#57423b]'
                                }`}
                              >
                                {phrase.status}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Actions: Toggle phrases / Reopen set */}
                  <div className="flex items-center justify-between pt-1">
                    <button
                      onClick={() => {
                        playPorcelainTap(1400);
                        setExpandedSetId(isExpanded ? null : item.id);
                      }}
                      className="text-[11px] text-[#635d59] hover:text-[#1c1c19] font-medium flex items-center gap-0.5 hover:underline"
                      type="button"
                    >
                      <span>{isExpanded ? 'Hide phrases' : 'View phrases'}</span>
                      <span className="material-symbols-outlined text-[14px]">
                        {isExpanded ? 'expand_less' : 'expand_more'}
                      </span>
                    </button>

                    <button
                      onClick={() => {
                        playPorcelainTap(1500);
                        onSelectPack(item.packId);
                        onClose();
                      }}
                      className="flex items-center gap-1 bg-[#9f3c16] hover:bg-[#bf542c] text-white px-3 py-1.5 rounded-full text-xs font-semibold shadow-2xs active:scale-95 transition-transform"
                      type="button"
                    >
                      <span className="material-symbols-outlined text-[15px] material-symbols-fill">
                        play_arrow
                      </span>
                      <span>Resume Set</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
