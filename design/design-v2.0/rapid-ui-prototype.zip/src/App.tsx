import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ScreenType, Phrase, CadencePack } from './types';
import { MAIN_CADENCE_PACK, SAMPLE_PHRASES } from './data/mockData';
import { NavigationHeader } from './components/NavigationHeader';
import { BottomNavBar } from './components/BottomNavBar';
import { MiniPlayer } from './components/MiniPlayer';
import { RhythmHomeScreen } from './screens/RhythmHomeScreen';
import { CadencePackDetailScreen } from './screens/CadencePackDetailScreen';
import { NowPlayingScreen } from './screens/NowPlayingScreen';
import { ListeningQueueScreen } from './screens/ListeningQueueScreen';
import { ExploreScreen } from './screens/ExploreScreen';
import { LibraryScreen } from './screens/LibraryScreen';
import { PackDownloadButton } from './components/PackDownloadButton';
import { speakSpanishPhrase, stopSpeaking, playPorcelainTap, triggerHaptic } from './utils/audioEngine';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('rhythm');
  const [activePack, setActivePack] = useState<CadencePack>(MAIN_CADENCE_PACK);
  const [currentPhrase, setCurrentPhrase] = useState<Phrase>(SAMPLE_PHRASES[0]);
  const [queuePhrases, setQueuePhrases] = useState<Phrase[]>(SAMPLE_PHRASES.slice(1));
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.25);
  const [isFavorite, setIsFavorite] = useState<boolean>(true);
  const [previousScreenBeforeModal, setPreviousScreenBeforeModal] = useState<ScreenType>('rhythm');

  // Stop audio on unmount
  useEffect(() => {
    return () => {
      stopSpeaking();
    };
  }, []);

  const handleTogglePlay = () => {
    if (isPlaying) {
      setIsPlaying(false);
      stopSpeaking();
      triggerHaptic('medium');
    } else {
      setIsPlaying(true);
      playPorcelainTap(1200);
      triggerHaptic('medium');
      speakSpanishPhrase(currentPhrase.spanish, playbackSpeed, () => {
        // Can continue playing or finish
      });
    }
  };

  const handleSelectPhrase = (phrase: Phrase) => {
    setCurrentPhrase(phrase);
    setIsPlaying(true);
    playPorcelainTap(1300);
    triggerHaptic('medium');
    speakSpanishPhrase(phrase.spanish, playbackSpeed);
  };

  const handleNextPhrase = () => {
    playPorcelainTap(1400);
    triggerHaptic('selection');
    const all = [currentPhrase, ...queuePhrases];
    const currentIndex = all.findIndex((p) => p.id === currentPhrase.id);
    const nextIndex = (currentIndex + 1) % all.length;
    const nextPhrase = all[nextIndex];
    setCurrentPhrase(nextPhrase);
    if (isPlaying) {
      speakSpanishPhrase(nextPhrase.spanish, playbackSpeed);
    }
  };

  const handlePreviousPhrase = () => {
    playPorcelainTap(1100);
    triggerHaptic('selection');
    const all = [currentPhrase, ...queuePhrases];
    const currentIndex = all.findIndex((p) => p.id === currentPhrase.id);
    const prevIndex = (currentIndex - 1 + all.length) % all.length;
    const prevPhrase = all[prevIndex];
    setCurrentPhrase(prevPhrase);
    if (isPlaying) {
      speakSpanishPhrase(prevPhrase.spanish, playbackSpeed);
    }
  };

  const handleToggleSpeed = () => {
    const speeds = [0.8, 1.0, 1.25];
    const nextIdx = (speeds.indexOf(playbackSpeed) + 1) % speeds.length;
    setPlaybackSpeed(speeds[nextIdx]);
    playPorcelainTap(1500);
    triggerHaptic('selection');
  };

  const handleSelectSpeed = (speed: number) => {
    setPlaybackSpeed(speed);
    playPorcelainTap(1500);
    triggerHaptic('selection');
  };

  const handleOpenPack = (packId: string) => {
    playPorcelainTap(1200);
    setCurrentScreen('pack-detail');
  };

  const handleStartWave = (waveId: string) => {
    handleSelectPhrase(SAMPLE_PHRASES[0]);
    setCurrentScreen('now-playing');
  };

  const handleOpenPlayer = () => {
    setPreviousScreenBeforeModal(currentScreen);
    setCurrentScreen('now-playing');
  };

  const handleOpenQueue = () => {
    setCurrentScreen('queue');
  };

  const handleCloseModal = () => {
    if (currentScreen === 'queue') {
      setCurrentScreen('now-playing');
    } else if (currentScreen === 'now-playing') {
      setCurrentScreen(previousScreenBeforeModal === 'now-playing' ? 'pack-detail' : previousScreenBeforeModal);
    }
  };

  const handleNavigateTab = (tab: ScreenType) => {
    playPorcelainTap(1600);
    setCurrentScreen(tab);
  };

  return (
    <div className="min-h-screen bg-[#fcf9f4] text-[#1c1c19] flex flex-col antialiased selection:bg-[#ffdbcf] selection:text-[#390c00] relative">
      {/* Top Navigation Header for non-fullscreen player screens */}
      {currentScreen !== 'now-playing' && currentScreen !== 'queue' && (
        <NavigationHeader
          title={
            currentScreen === 'pack-detail'
              ? 'Cadence Pack Detail'
              : currentScreen === 'explore'
              ? 'Explore'
              : currentScreen === 'library'
              ? 'Library'
              : undefined
          }
          showBack={currentScreen === 'pack-detail'}
          onBack={() => setCurrentScreen('rhythm')}
          showStreak={currentScreen === 'rhythm'}
          rightAction={
            currentScreen === 'pack-detail' ? (
              <PackDownloadButton
                pack={activePack}
                onDownloadComplete={() => {
                  setActivePack((prev) => ({ ...prev, cached: true }));
                }}
                onRemoveFromCache={() => {
                  setActivePack((prev) => ({ ...prev, cached: false }));
                }}
              />
            ) : undefined
          }
        />
      )}

      {/* Main Content Area */}
      <div className={`flex-1 ${currentScreen !== 'now-playing' && currentScreen !== 'queue' ? 'pt-16' : ''}`}>
        <AnimatePresence mode="wait">
          {currentScreen === 'rhythm' && (
            <motion.div
              key="rhythm"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
            >
              <RhythmHomeScreen
                onOpenPack={handleOpenPack}
                onStartWave={handleStartWave}
                onPlayPhrase={handleSelectPhrase}
                pack={activePack}
                isPlaying={isPlaying}
                currentPhrase={currentPhrase}
                onTogglePlay={handleTogglePlay}
              />
            </motion.div>
          )}

          {currentScreen === 'pack-detail' && (
            <motion.div
              key="pack-detail"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.24, ease: 'easeOut' }}
            >
              <CadencePackDetailScreen
                pack={activePack}
                currentPhrase={currentPhrase}
                isPlaying={isPlaying}
                onTogglePlay={handleTogglePlay}
                onSelectPhrase={handleSelectPhrase}
                onNextPhrase={handleNextPhrase}
                onPreviousPhrase={handlePreviousPhrase}
                playbackSpeed={playbackSpeed}
                onToggleSpeed={handleToggleSpeed}
                onOpenPlayer={handleOpenPlayer}
                onBack={() => setCurrentScreen('rhythm')}
              />
            </motion.div>
          )}

          {currentScreen === 'explore' && (
            <motion.div
              key="explore"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
            >
              <ExploreScreen
                onOpenPack={handleOpenPack}
                onPlayPhrase={handleSelectPhrase}
              />
            </motion.div>
          )}

          {currentScreen === 'library' && (
            <motion.div
              key="library"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
            >
              <LibraryScreen
                onOpenPack={handleOpenPack}
                onPlayPhrase={handleSelectPhrase}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Full-Screen Now Playing Modal Screen with Expanding Bottom Spring Animation */}
      <AnimatePresence>
        {currentScreen === 'now-playing' && (
          <motion.div
            key="now-playing-modal"
            initial={{
              y: '85%',
              scale: 0.88,
              opacity: 0.4,
              borderRadius: '32px',
            }}
            animate={{
              y: 0,
              scale: 1,
              opacity: 1,
              borderRadius: '0px',
            }}
            exit={{
              y: '85%',
              scale: 0.88,
              opacity: 0.4,
              borderRadius: '32px',
            }}
            style={{ transformOrigin: 'bottom center' }}
            transition={{
              type: 'spring',
              damping: 27,
              stiffness: 270,
              mass: 0.85,
            }}
            className="fixed inset-0 z-50 overflow-hidden"
          >
            <NowPlayingScreen
              phrase={currentPhrase}
              isPlaying={isPlaying}
              onTogglePlay={handleTogglePlay}
              onPrevious={handlePreviousPhrase}
              onNext={handleNextPhrase}
              playbackSpeed={playbackSpeed}
              onSelectSpeed={handleSelectSpeed}
              onOpenQueue={handleOpenQueue}
              onClose={handleCloseModal}
              isFavorite={isFavorite}
              onToggleFavorite={() => setIsFavorite(!isFavorite)}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Full-Screen Listening Queue Modal Screen with Spring Slide-Up */}
      <AnimatePresence>
        {currentScreen === 'queue' && (
          <motion.div
            key="queue-modal"
            initial={{ y: '100%', opacity: 0.8 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: '100%', opacity: 0.8 }}
            transition={{ type: 'spring', damping: 28, stiffness: 280 }}
            className="fixed inset-0 z-50 overflow-hidden"
          >
            <ListeningQueueScreen
              currentPhrase={currentPhrase}
              queuePhrases={queuePhrases}
              isPlaying={isPlaying}
              onTogglePlay={handleTogglePlay}
              onSelectPhrase={handleSelectPhrase}
              onPrevious={handlePreviousPhrase}
              onNext={handleNextPhrase}
              playbackSpeed={playbackSpeed}
              onToggleSpeed={handleToggleSpeed}
              onClose={handleCloseModal}
              onReorderQueue={(newQueue) => setQueuePhrases(newQueue)}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Persistent Docked Mini-Player on Rhythm, Explore, and Library with Slide/Fade */}
      <AnimatePresence>
        {(currentScreen === 'rhythm' ||
          currentScreen === 'explore' ||
          currentScreen === 'library') && (
          <motion.div
            key="docked-miniplayer"
            initial={{ y: 50, opacity: 0, scale: 0.96 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 50, opacity: 0, scale: 0.96 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed bottom-[56px] sm:bottom-[60px] inset-x-3 sm:inset-x-6 z-30 max-w-lg md:max-w-xl lg:max-w-2xl mx-auto pointer-events-auto"
          >
            <MiniPlayer
              currentPhrase={currentPhrase}
              isPlaying={isPlaying}
              onTogglePlay={handleTogglePlay}
              onNext={handleNextPhrase}
              onPrevious={handlePreviousPhrase}
              playbackSpeed={playbackSpeed}
              onToggleSpeed={handleToggleSpeed}
              onOpenPlayer={handleOpenPlayer}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Persistent Bottom Nav Bar on standard views */}
      {currentScreen !== 'now-playing' &&
        currentScreen !== 'queue' &&
        currentScreen !== 'pack-detail' && (
          <BottomNavBar
            currentScreen={currentScreen}
            onNavigate={handleNavigateTab}
          />
        )}
    </div>
  );
}
